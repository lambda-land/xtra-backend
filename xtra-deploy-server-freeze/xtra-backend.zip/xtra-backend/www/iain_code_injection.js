

const source = '<li class="nav-item"><a class="nav-link" id="help-link" style="cursor: pointer;">Help</a></li>';

const main = () => {
	const parent = document.getElementsByClassName('navbar-nav mr-auto')[0];
	parent.innerHTML += source;
	const help = document.getElementById('help-link');
	help.href = 'Tracr-HowTo.pdf';
	
};

setTimeout(() => main(), 100);
