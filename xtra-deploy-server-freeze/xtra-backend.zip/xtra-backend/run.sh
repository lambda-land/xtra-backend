#!/bin/bash
sudo cabal run server 80
