{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE TupleSections #-}

module Xtra.Runtime.DagEvaluator where

import           Xtra.Language.Syntax
import qualified Xtra.Language.Env as Env
import           Xtra.Runtime.EvalDAG hiding (nodes, scopes)

import           Control.Applicative
import           Control.Monad.Except
import           Control.Monad.State

import           Data.Bifunctor
import           Data.Functor.Identity
import           Data.List
import qualified Data.Map.Lazy                 as Map
import           Data.Maybe
import qualified Data.Set                      as Set
import           Debug.Trace

type Map = Map.Map

type Set = Set.Set

type BindN = (Var, (NodeId, NodeId))

type StrippedEnv = [(Var, NamedVal)]

data EvaluatorState =
    EvaluatorState
        { cache :: [(Eval, NodeId)] -- TODO Ord?
        , envCache :: [((Var, Val), NodeId)]
        , nodes :: Map NodeId (Node, [NodeId])
        , scopes :: Map NodeId (Set Var)
        , localEnv :: SimpleEnv
        , usedVariables :: Set String
        , currentEdges :: [NodeId]
        , nextId :: NodeId
        , tryFunctionName :: Bool
        }

type DagEvaluator = StateT EvaluatorState (ExceptT String Identity)

freshId :: DagEvaluator NodeId
freshId = gets nextId <* modify (\s -> s { nextId = succ $ nextId s })

insertPairBack :: (NodeId, NodeId) -> [(NodeId, NodeId)] -> [(NodeId, NodeId)]
insertPairBack n [] = [n]
insertPairBack n (n' : ns) | n == n'   = n' : ns
                           | otherwise = n' : insertPairBack n ns

addScopePairEnv :: String -> ScopePair -> Env -> Env
addScopePairEnv x n = Env.alter (fmap (second (insertPairBack n))) x

addScopePair :: String -> ScopePair -> Node -> Node
addScopePair x n (RNode t x' v ns)
  | x == x'   = RNode t x' v $ insertPairBack n ns
  | otherwise = RNode t x' v ns
addScopePair x n (SNode t (Eval env e v l)) = SNode t
  $ Eval newEnv e v l
  where newEnv = addScopePairEnv x n env
addScopePair _ _ s = s

addSimpleEnv :: SimpleEnv -> Env -> Env
addSimpleEnv senv env = foldr keyTransform env (Env.keys senv)
 where
  keyTransform x env' = case Env.get x senv of
    Just (_, i) -> addScopePairEnv x i env'
    Nothing     -> env'

updateNodeEnv :: SimpleEnv -> Node -> Node
updateNodeEnv senv (SNode t (Eval env e v l)) =
  SNode t $ Eval (addSimpleEnv senv env) e v l

alter :: Eq a => (Maybe b -> Maybe b) -> a -> [(a, b)] -> [(a, b)]
alter f k [] = fromMaybe [] $ (return . (k, )) <$> f Nothing
alter f k ((a, b) : xs)
  | a == k    = fromMaybe xs $ ((: xs) . (a, )) <$> f (Just b)
  | otherwise = (a, b) : alter f k xs

transformNode
  :: NodeId
  -> (Node -> Node)
  -> Map NodeId (Node, [NodeId])
  -> Map NodeId (Node, [NodeId])
transformNode n f = Map.alter (fmap (first f)) n

addBind :: (Var, (NodeId, NodeId)) -> NamedVal -> DagEvaluator NodeId
addBind (x, ns) v = do
  ch    <- gets envCache
  newId <- freshId
  let newNode  = RNode tag x v [ns]
  let cacheKey = (x, getValue v)
  modify $ \s -> s
    { nodes    = Map.insert newId (newNode, nub $ currentEdges s)
                   $ case lookup cacheKey ch of
                       Nothing -> nodes s
                       Just oldKey ->
                         transformNode oldKey (addScopePair x ns) (nodes s)
    , envCache = alter (<|> Just newId) cacheKey $ ch
    }
  return $ fromMaybe newId $ lookup cacheKey ch

addCache :: Eval -> DagEvaluator NodeId
addCache eval = do
  c     <- gets cache
  newId <- freshId
  let newNode = SNode tag eval
  modify $ \s -> s
    { nodes = Map.insert newId (newNode, nub $ currentEdges s) (nodes s)
    , cache = alter (<|> Just newId) eval $ cache s
    }
  return $ fromMaybe newId $ lookup eval c

addCacheEval :: SimpleEnv -> Expr -> NamedVal -> ELabel -> DagEvaluator NodeId
addCacheEval env e v l = do
  i <- addCache (Eval (fromSimple env) e v l)
  modify $ \s -> s { nodes = transformNode i (updateNodeEnv env) (nodes s) }
  return i

addUsedVariable :: String -> DagEvaluator ()
addUsedVariable v =
  modify (\s -> s { usedVariables = Set.insert v $ usedVariables s })

insertEdge :: NodeId -> [NodeId] -> [NodeId]
insertEdge n = (++ [n])

addEdge :: NodeId -> DagEvaluator ()
addEdge i = modify (\s -> s { currentEdges = insertEdge i $ currentEdges s })

addEdgeBetween :: NodeId -> NodeId -> DagEvaluator ()
addEdgeBetween f t = modify
  $ \s -> s { nodes = Map.adjust (second (nub . insertEdge t)) f (nodes s) }

getEnv :: DagEvaluator SimpleEnv
getEnv = gets localEnv

orEval :: DagEvaluator a -> DagEvaluator a -> DagEvaluator a
orEval l r = catchError l (const r)

failEval :: String -> Expr -> DagEvaluator a
failEval s _ = throwError s

edgeOf :: DagEvaluator (a, NodeId) -> DagEvaluator a
edgeOf e = do
  let useEdge (v, i) = addEdge i >> return v
  scopeEdges e >>= useEdge

ignoreId :: DagEvaluator (a, NodeId) -> DagEvaluator a
ignoreId = (fst <$>)

minimalEnv :: [String] -> GenEnv a -> GenEnv a
minimalEnv xs = Env.filter ((`elem` xs) . fst)

withEnv :: SimpleEnv -> DagEvaluator a -> DagEvaluator a
withEnv env e = do
  env' <- gets localEnv
  modify (\s -> s { localEnv = env }) *> e <* modify
    (\s -> s { localEnv = env' })

withBinding :: NodeId -> Var -> NamedVal -> DagEvaluator a -> DagEvaluator a
withBinding i x v e = withLastId $ \lastId -> withScopedBinding i lastId x v e

withScopedBinding
  :: NodeId -> NodeId -> Var -> NamedVal -> DagEvaluator a -> DagEvaluator a
withScopedBinding i j x v e = do
  env <- getEnv
  modify (\s -> s { scopes = addToSet j x $ scopes s })
  withEnv (Env.bind x v (i, j) env) e

addToSet :: (Ord k, Ord v) => k -> v -> Map k (Set v) -> Map k (Set v)
addToSet k v m = Map.insert k (Set.insert v $ Map.findWithDefault Set.empty k m) m

withBindings :: NodeId -> VBinding -> DagEvaluator a -> DagEvaluator a
withBindings i bs e = foldl (\e' (x, v) -> withBinding i x v e') e bs

mkBind
  :: Var -> DagEvaluator (NamedVal, (NodeId, NodeId)) -> DagEvaluator NamedVal
mkBind x e = edgeOf $ do
  (v, is) <- e
  i       <- addBind (x, is) v
  return (v, i)

mkEval :: ELabel -> Expr -> DagEvaluator NamedVal -> DagEvaluator NamedVal
mkEval l ex e = edgeOf $ do
  env     <- getEnv
  (v, xs) <- usedVars e
  let menv = minimalEnv xs env
  i <- addCacheEval menv ex v l
  return (v, i)

mkCondEval
  :: Expr
  -> DagEvaluator NamedVal
  -> (NamedVal -> DagEvaluator (NamedVal, ELabel))
  -> DagEvaluator NamedVal
mkCondEval ex e f = edgeOf $ do
  env            <- getEnv
  (v      , xs ) <- usedVars e
  ((v', l), xs') <- usedVars $ f v
  let menv = minimalEnv (xs ++ xs') env
  i <- addCacheEval menv ex v' l
  return (v', i)

mkNonemptyMatch
  :: MLabel -> NamedVal -> Pat -> DagEvaluator VBinding -> DagEvaluator VBinding
mkNonemptyMatch l v p e = do
  bs <- scopeEdges $ mkMatch l v p e
  if null bs then return bs else mkMatch l v p e

withLastId :: (NodeId -> DagEvaluator a) -> DagEvaluator a
withLastId e = do
  rec (v, ids) <- createdEdges $ e (last ids)
  return v

mkMatch
  :: MLabel -> NamedVal -> Pat -> DagEvaluator VBinding -> DagEvaluator VBinding
mkMatch l v p e = edgeOf $ do
  bs <- e
  let newNode = Match v p bs l
  i <- addCache newNode
  return (bs, i)

mkPrim :: PLabel -> Op -> Val -> Val -> DagEvaluator Val -> DagEvaluator Val
mkPrim l o vl vr e = edgeOf $ do
  v <- e
  let newNode = Prim o vl vr v l
  i <- addCache newNode
  return (v, i)

scopeEdges :: DagEvaluator a -> DagEvaluator a
scopeEdges e = do
  edges <- gets currentEdges
  modify (\s -> s { currentEdges = [] })
  e <* modify (\s -> s { currentEdges = edges })

scopeVars :: DagEvaluator a -> DagEvaluator a
scopeVars e = do
  xs <- gets usedVariables
  modify (\s -> s { usedVariables = Set.empty })
  e <* modify (\s -> s { usedVariables = xs })

limitVars :: DagEvaluator a -> DagEvaluator a
limitVars e = do
  xs <- gets usedVariables
  modify (\s -> s { usedVariables = Set.empty })
  e <* modify (\s -> s { usedVariables = usedVariables s `Set.union` xs })

usedVars :: DagEvaluator a -> DagEvaluator (a, [String])
usedVars e = limitVars $ (,) <$> e <*> (Set.toList <$> gets usedVariables)

listMinus :: Eq a => [a] -> [a] -> [a]
listMinus from del = foldr delete from del

createdEdges :: DagEvaluator a -> DagEvaluator (a, [NodeId])
createdEdges e = do
  edgesBefore <- gets currentEdges
  v           <- e
  edgesAfter  <- gets currentEdges
  return (v, edgesAfter `listMinus` edgesBefore)

requireFunctionName :: Expr -> DagEvaluator ()
requireFunctionName e = do
  b <- gets tryFunctionName
  if b then return () else failEval "CBFN disabled." e

initialState :: SimpleEnv -> EvaluatorState
initialState env = EvaluatorState { cache           = []
                                  , envCache        = []
                                  , nodes           = Map.empty
                                  , scopes          = Map.empty
                                  , localEnv        = env
                                  , usedVariables   = Set.empty
                                  , currentEdges    = []
                                  , nextId          = 0
                                  , tryFunctionName = True
                                  }

createGraph :: DagEvaluator EvalGr
createGraph = liftA3 EvalGr (gets nodes) (gets scopes) ((+ (-1)) <$> gets nextId)

runEvaluator' :: DagEvaluator a -> SimpleEnv -> Either String (a, EvalGr)
runEvaluator' e = runExcept . evalStateT action . initialState
 where
  action = (,) <$> e <*> createGraph

runEvaluator :: DagEvaluator a -> SimpleEnv -> Either String a
runEvaluator e = runExcept . evalStateT e . initialState
