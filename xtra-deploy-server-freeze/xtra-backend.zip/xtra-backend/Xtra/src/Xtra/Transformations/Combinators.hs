module Xtra.Transformations.Combinators where

-- Combinators
xor :: Bool -> Bool -> Bool
xor a b = (a || b) && not (a && b)

(&&&) :: (a -> Bool) -> (a -> Bool) -> a -> Bool
(&&&) = liftPred (&&)

(|||) :: (a -> Bool) -> (a -> Bool) -> a -> Bool
(|||) = liftPred (||)

(^^^) :: (a -> Bool) -> (a -> Bool) -> a -> Bool
(^^^) = liftPred xor

notP :: (a -> Bool) -> a -> Bool
notP = (.) not

liftPred :: (Bool -> Bool -> Bool) -> (a -> Bool) -> (a -> Bool) -> a -> Bool
liftPred f p q e = f (p e) (q e)
