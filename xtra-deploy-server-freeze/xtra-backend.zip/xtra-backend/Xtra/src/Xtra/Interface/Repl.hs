{-# LANGUAGE FlexibleInstances #-}
-- |

module Xtra.Interface.Repl where

import           Prelude                 hiding ( getLine )

import           Control.Monad.State.Lazy

import           Xtra.Language.Prog

import           Xtra.Runtime.Eval

import           System.Console.Haskeline

import           Text.Parsec

import           Xtra.Language.Syntax
import           Xtra.Language.Hole
import           Xtra.Runtime.EvalDAG
import           Xtra.Interface.Monad
import           Xtra.Interface.Parser
import           Xtra.Interface.QueryLang
import           Xtra.Transformations.Selectors

import qualified Data.Map                      as M

getCommand :: REPL Bool
getCommand = do
  ml <- getLine
  case ml of
    Just l -> runCommand l *> return True
    Nothing -> return False
  where
    runCommand l = do
      q <- gets (qEnv . head)
      case parse (parseLine q) "" l of -- safe head, but this should be fixed later.
        Right (Right o) -> o
        Right (Left g) -> doOp g l
        Left  err       -> println (show err)

prelude :: QueryEnv
prelude = M.fromList
    [ ("all", Left $ QueryFunction [] $ EvalPattern $ EvalHole $ Hole "X")
    , ("first", Left $ QueryFunction ["s"] $ s `Except` (s `Then` (s `Except` Root)))
    , ("firsttwo", Left $ QueryFunction ["s"] $ s `Except` (s `Then` ((s `Except` Root) `Then` QApp "descendants" [])))
    , ("firstthree", Left $ QueryFunction ["s"] $ s `Except` (s `Then` ((s `Except` Root) `Then` QApp "descendants" [] `Then` QApp "descendants" [])))
    , ("last", Left $ QueryFunction ["s"] $ Fix $ Try $ s `Except` Root)
    --, ("lasttwo", Left $ QueryFunction ["s"] $ QApp "last" [s] `Or` ((QApp "all" [] `Except` QApp "last" [s]) `Then` QApp "last" [s]))
    , ("descendants", Left $ QueryFunction [] $ QApp "all" [] `Except` Root)
    , ("children", Left $ QueryFunction [] $ QApp "first" [QApp "descendants" []])
    , ("nonFirst", Left $ QueryFunction ["s"] $ (s `Except` QApp "first" [s]) `Then` QApp "descendants" [])
    , ("nonFirstTwo", Left $ QueryFunction ["s"] $ (s `Except` (QApp "firsttwo" [s])) `Then` QApp "descendants" [])
    , ("nonFirstThree", Left $ QueryFunction ["s"] $ (s `Except` (QApp "firstthree" [s])) `Then` QApp "descendants" [])
    , ("afterLast", Left $ QueryFunction ["s"] $ QApp "last" [s] `Then` QApp "all" [])
    , ("reflexive", Left $ QueryFunction [] $ EvalPattern $ HEval (ExprExt x) (NamedVal (ValExt x) []))
    , ("binding", Left $ QueryFunction [] $ BindingPattern (Left x) (Left y))
    , ("pattern", Left $ QueryFunction [] $ EvalPattern $ HMatch (NamedVal (ValExt x) []) (PatExt y))
    ]
    where
        s = QApp "s" []
        x = Hole "X"
        y = Hole "Y"

runRepl :: Prog -> IO ()
runRepl p = do
  runInputT defaultSettings $ evalStateT (writeTrace "out.dot" >> repl') [e]
 where
  e       = Env t Nothing undefined prelude -- fix
  t = progTrace p
  repl' :: REPL ()
  repl' =
    (do
      keepRunning <- getCommand
      if keepRunning
        then do writeTrace "out.dot"; repl'
        else writeStats
    )
