-- |
module Xtra.Interface.QueryLang (Query(..), QueryFunction(..), QueryVar(..), constQ, compile) where
import Xtra.Language.Syntax
import Xtra.Language.Hole
import Control.Monad.Reader hiding (fix)
import Control.Monad.Except hiding (fix)
import Control.Monad.State hiding (fix)
import Control.Monad hiding (fix)
import Data.List
import Prelude hiding (until)
import qualified Data.Map as M
import Data.Maybe

import Xtra.Runtime.EvalDAG
import Xtra.Transformations.Selectors

type Pred a = a -> Bool
type Name = String

-- Query AST
data Query = EvalPattern HoleEval
           | BindingPattern (Either Hole Var) (Either Hole (NamedExtVal Hole)) 
           | QApp String [Query]
           | Query `And` Query
           | Query `Or` Query
           | Query `Except` Query
           | Query `Then` Query
           | Fix Query
           | Try Query
           | Root

type QueryVar = Either QueryFunction Selector

data QueryFunction = QueryFunction [String] Query

constQ :: Query -> QueryFunction
constQ = QueryFunction []

instance Show Query where
  show (EvalPattern e) = "<??>"
  show (BindingPattern x v) = either show id x ++ " = " ++ either show show v
  show (QApp s qs) = intercalate " " $ s : (show <$> qs)
  show (l `And` r) = show l ++ " and " ++ show r
  show (l `Or` r) = show l ++ " or " ++ show r
  show (l `Except` r) = show l ++ " except " ++ show r
  show (l `Then` r) = "(" ++ show l ++ ") then (" ++ show r ++ ")"
  show (Fix q) = "fix " ++ show q
  show (Try q) = "try " ++ show q
  show (Root) = "root"


type QueryEnv = M.Map String QueryVar
type Compiler = ExceptT String (Reader QueryEnv)

filterFrom :: (Node -> Bool) -> NodeId -> EvalGr -> [NodeId]
filterFrom p i gr = case M.lookup i (nodes gr) of
    Just (n, is) -> if p n then i : rest else rest
        where rest = concatMap (flip (filterFrom p) gr) is
    Nothing -> []

matchGraphS :: HoleEval -> Selector
matchGraphS m gr = filterFrom matchS (rootNode gr) gr
    where
        matchS (SNode _ e) = runMatch $ matchHoleyEval m e
        matchS _ = False

matchGraphR :: Either Hole String -> Either Hole (NamedExtVal Hole) -> Selector
matchGraphR ex ev gr = filterFrom matchR (rootNode gr) gr
    where
        matchR (RNode _ x v _) =
            either (const True) (==x) ex &&
            either (const True) (runMatch . flip matchNamedHoleyVal v) ev
        matchR _ = False

compile :: QueryEnv -> Query -> Either String Selector
compile qenv = flip runReader qenv . runExceptT . compile'
    where
        applyQuery :: String -> QueryVar -> [Query] -> Compiler Selector
        applyQuery s (Right sel) [] = return sel
        applyQuery s (Right _) _ = throwError $ "Can't apply non-function " ++ s
        applyQuery s (Left (QueryFunction ps q)) qs
            | length ps == length qs = do
                ss <- mapM ((Right <$>) . compile') qs
                local (const $ foldr ($) qenv $ zipWith M.insert ps ss) $ compile' q
            | otherwise = throwError $ "Incompatible arity " ++ show (length ps) ++ " " ++ show (length qs) ++ ": " ++ s

        compile' :: Query -> Compiler Selector
        compile' (EvalPattern (EvalHole _)) = return everywhere
        compile' (EvalPattern p) = return $ matchGraphS p
        compile' (BindingPattern ex ev) = return $ matchGraphR ex ev
        compile' (QApp s qs) = do
            mqf <- lift $ reader (M.lookup s)
            maybe (throwError $ "Unknown query variable " ++ s) (flip (applyQuery s) qs) mqf
        compile' (q1 `And` q2) = liftM2 and_ (compile' q1) (compile' q2)
        compile' (q1 `Or` q2) = liftM2 or_ (compile' q1) (compile' q2)
        compile' (q1 `Except` q2) = liftM2 except (compile' q1) (compile' q2)
        compile' (q1 `Then` q2) = liftM2 then_ (compile' q1) (compile' q2)
        compile' (Fix q) = fix_ <$> compile' q
        compile' (Try q) = try_ <$> compile' q
        compile' Root = return root
