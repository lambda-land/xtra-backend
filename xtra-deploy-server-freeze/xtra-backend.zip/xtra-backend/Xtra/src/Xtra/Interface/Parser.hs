-- |

module Xtra.Interface.Parser where


import Prelude hiding (all, getLine, pred, until, lex, fix)

import Text.Parsec.Expr
import Text.Parsec
import Xtra.Language.Syntax

import Xtra.Language.Parser (parseProg)
import Xtra.Language.Prog
import Xtra.Language.Hole

import Control.Monad
import Control.Monad.IO.Class
import Control.Monad.State (gets)

import Data.Maybe

import Xtra.Runtime.EvalDAG
import qualified Data.Map as M
import Xtra.Transformations.Operations
import Xtra.Transformations.Selectors
import Xtra.Interface.QueryLang

import Xtra.Interface.Monad

import qualified Xtra.Language.Parser as L

type Resolver = NodeId -> Node

type Parser =  L.Parser

lex :: String -> Parser String
lex x = try $ (string x <* whiteSpace)

ident :: Parser String
ident = try $ do
    str <- many1 alphaNum <* whiteSpace
    if str `elem` ["and", "or", "then", "except"]
     then fail "Reserved keyword"
     else return str

whiteSpace :: Parser String
whiteSpace = many space

parseSys :: Parser (REPL ())
parseSys = (lex "print" *> (writeTrace <$> ident))  <|>
           (lex "save" *> (writeScript <$> ident)) <|>
           (lex "stack" *> pure printStack) <|>
           (lex "undo" *>  pure undo) <|>
           (lex "load" *> (readScript <$> ident)) <|>
           (lex "env" *> pure dispEnv) <|>
           (do
             name <- ident
             vars <- many ident
             lex "="
             q <- parseQuery
             pure $ println (show q) >> put name (QueryFunction vars q))

angles :: Parser a -> Parser a
angles p = whiteSpace *> char '<' *> p <* char '>' <* whiteSpace

name :: String -> HoleEval
name s = HEval (App (Ref s) (ExprExt (Hole "x"))) (NamedVal (ValExt (Hole "y")) [])

parseHoleEval :: Parser HoleEval
parseHoleEval = (try $ HEval <$> (L.parseExtExpr L.parseHole) <*> (whiteSpace *> lex "=>" *> (L.parseNamedExtVal L.parseHole))) <|>
                (try $ HMatch <$> (L.parseNamedExtVal L.parseHole) <*> (lex "~>" *> L.parseExtPat L.parseHole)) <|>
                (try $ (flip HPrim) <$> (L.parseExtVal L.parseHole) <*> parseOp <*> (L.parseExtVal L.parseHole) <*> (lex "==" *> L.parseExtVal L.parseHole)) <|>
                (try $ EvalHole <$> L.parseHole)

parseOperation :: M.Map String QueryVar -> Parser Operation
parseOperation f =
  (try $ lex "accept" *> (Accept <$> parseSelector f)) <|>
  (try $ lex "hide" *> (Hide <$> parseSelector f)) <|>
  (try $ lex "factor" *> (Factor <$> parseSelector f))

parseSelector :: M.Map String QueryVar -> Parser Selector
parseSelector env = either error return =<< (compile env <$> parseQuery)

parseQuery :: Parser Query
parseQuery = buildExpressionParser ops parseQuery'
  where
    ops = return
        [ binOp "and" And AssocLeft, binOp "or" Or AssocLeft
        , binOp "then" Then AssocLeft, binOp "except" Except AssocLeft
        ]

binOp n f a = Infix (try $ (lex n *> pure f)) a

parseParens p = lex "(" *> p <* lex ")"

parseBinding :: Parser Query
parseBinding = try $ uncurry BindingPattern <$>
    angles (liftM2 (,) ((Left <$> L.parseHole <|> Right <$> ident) <* lex "=") (Right <$> L.parseNamedExtVal L.parseHole))

parseQuery' :: Parser Query
parseQuery' = (parseParens parseQuery) <|>
         (try $ lex "root" *> pure Root) <|>
         (try $ lex "fix" *> (Fix <$> parseQuery)) <|>
         (try $ lex "try" *> (Try <$> parseQuery)) <|>
         (try $ EvalPattern <$> angles parseHoleEval) <|>
         (try $ parseBinding) <|>
         (try $ do
                _ <- char ','
                n <- ident
                return $ EvalPattern (name n)
         ) <|>
         (liftM2 QApp ident (many parseQuery)) -- TODO Bad precedence

-- >>= (\x -> either (error) (id) (compileQuery x (QEnv env node)))

parseOp :: Parser (Op)
parseOp = (spaces *> string "+" *> spaces *> (pure $ Plus)) <|>
          (spaces *> string "-" *> spaces *> (pure $ Minus)) <|>
          (spaces *> string "*" *> spaces *> (pure $ Times)) <|>
          (spaces *> string "/" *> spaces *> (pure $ Div)) <|>
          (spaces *> string ">" *> spaces *> (pure $ Gt)) <|>
          (spaces *> string "%" *> spaces *> (pure $ Mod))

readScript :: String -> (REPL ())
readScript f = do
  ls <- liftIO $ readFile f
  forM_ (lines ls) $ \l -> do
    case l of
      "" -> pure ()
      l' -> do
        q <- gets (qEnv . head)
        case parse (parseLine q) "" l of -- safe head, but this should be fixed later.
          Right (Right o) -> o
          Right (Left gr) -> doOp gr l
          Left err -> println (show err)

parseLine :: M.Map String QueryVar -> Parser (Either Operation (REPL ()))
parseLine f = Left <$> (parseOperation f) <|>
              Right <$> parseSys
