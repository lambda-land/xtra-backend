module Xtra.Examples.Examples where

import           Xtra.Language.Prog
import           Xtra.Language.Syntax
import           Xtra.Examples.HaskellCode(Tree(..), createBST', insert)



-- Smart Constructors For Expressions
{-| Generates an expression that is a list of the given expressions.
 -}
genList :: [Expr] -> Expr
genList xs = foldr ($) (dcon "Nil") (map (app . app (dcon "Cons")) xs)

{-| Generates an expression that is a list of the given integers.
 -}
genIlist :: [Int] -> Expr
genIlist = genList . map icon

--foo = (\x. x (\fact. (x fact)))
fooBody :: Decl
fooBody = let_ "foo"
  $ abs_ "x" (app (ref "x") (abs_ "twice" (app (ref "x") (ref "twice"))))

fooProg :: Prog
fooProg = prog [twiceBody, fooBody] $ app (ref "foo") (ref "twice")

idBody :: Decl
idBody = let_ "id" $ abs_ "x" (ref "x")

-- check for collision of two rectangles, defined as top left, bottom right pairs
collideBodyBroken :: Decl
collideBodyBroken = let_ "collide" $ abs_ "r1"
  $ abs_ "r2" $ case_ (ref "r1")
  [ (CPat "Rect" [CPat "Point" [VPat "tx1", VPat "ty1"], CPat "Point" [VPat "bx1", VPat "by1"]],
     case_ (ref "r2")
     [
       (CPat "Rect" [CPat "Point" [VPat "tx2", VPat "ty2"], CPat "Point" [VPat "bx2", VPat "by2"]],
        apps (ref "or") [apps (ref "and") [apps (ref "between") [ref "bx1", ref "tx2", ref "tx1"]
                                          ,apps (ref "between") [ref "by1", ref "ty2", ref "ty2"]]
                        ,apps (ref "and") [apps (ref "between") [ref "bx1", ref "bx2", ref "tx1"]
                                          ,apps (ref "between") [ref "by1", ref "by2", ref "ty2"]]])])]

collideBody :: Decl
collideBody = let_ "collide" $ abs_ "r1"
  $ abs_ "r2" $ case_ (ref "r1")
  [ (CPat "Rect" [CPat "Point" [VPat "tx1", VPat "ty1"], CPat "Point" [VPat "bx1", VPat "by1"]],
     case_ (ref "r2")
     [
       (CPat "Rect" [CPat "Point" [VPat "tx2", VPat "ty2"], CPat "Point" [VPat "bx2", VPat "by2"]],
        apps (ref "or") [apps (ref "and") [apps (ref "between") [ref "tx1", ref "tx2", ref "bx1"]
                                          ,apps (ref "between") [ref "by1", ref "ty2", ref "ty2"]]
                        ,apps (ref "and") [apps (ref "between") [ref "tx1", ref "bx2", ref "bx1"]
                                          ,apps (ref "between") [ref "by1", ref "by2", ref "ty2"]]])])]

collideProgBroken :: (Int, Int, Int, Int) -> (Int, Int, Int, Int) -> Prog
collideProgBroken (tx1, ty1, bx1, by1) (tx2, ty2, bx2, by2) = prog [andBody, orBody, geqBody, betweenBody, collideBodyBroken] $
  apps (ref "collide") [apps (dcon "Rect") [apps (dcon "Point") [icon tx1, icon ty1], apps (dcon "Point") [icon bx1, icon by1]]
                 ,apps (dcon "Rect") [apps (dcon "Point") [icon tx2, icon ty2], apps (dcon "Point") [icon bx2, icon by2]]]


collideProgBroken2 :: (Int, Int, Int, Int) -> (Int, Int, Int, Int) -> Prog
collideProgBroken2 (tx1, ty1, bx1, by1) (tx2, ty2, bx2, by2) = prog [andBody, orBody, geqBodyBroken, betweenBody, collideBody] $
  apps (ref "collide") [apps (dcon "Rect") [apps (dcon "Point") [icon tx1, icon ty1], apps (dcon "Point") [icon bx1, icon by1]]
                 ,apps (dcon "Rect") [apps (dcon "Point") [icon tx2, icon ty2], apps (dcon "Point") [icon bx2, icon by2]]]

collideProg :: (Int, Int, Int, Int) -> (Int, Int, Int, Int) -> Prog
collideProg (tx1, ty1, bx1, by1) (tx2, ty2, bx2, by2) = prog [andBody, orBody, geqBody, notBody, betweenBody, collideBody, equalBody] $
  apps (ref "collide") [apps (dcon "Rect") [apps (dcon "Point") [icon tx1, icon ty1], apps (dcon "Point") [icon bx1, icon by1]]
                 ,apps (dcon "Rect") [apps (dcon "Point") [icon tx2, icon ty2], apps (dcon "Point") [icon bx2, icon by2]]]

betweenBody :: Decl
betweenBody = let_ "between" $ abs_ "x" $ abs_"y" $ abs_ "z" $
  apps (ref "and") [apps (ref "geq") [ref "y", ref "x"], apps (ref "geq") [ref "z", ref "y"]]



betweenProg :: Int -> Int -> Int -> Prog
betweenProg x y z = prog [andBody, orBody, geqBody, betweenBody]
  $ apps (ref "between") [icon x, icon y, icon z]

andBody :: Decl
andBody =
    let_ "and" $ abs_ "l" $ abs_ "r" $
        case_ (ref "l")
            [ (BPat False, bcon False)
            , (BPat True, ref "r")
            ]

orBody :: Decl
orBody =
    let_ "or" $ abs_ "l" $ abs_ "r" $
        case_ (ref "l")
            [ (BPat True, bcon True)
            , (BPat False, ref "r")
            ]

boolEvalCases :: (Expr -> Expr) -> [Branch]
boolEvalCases ev =
    [ (CPat "True" [], bcon True)
    , (CPat "False" [], bcon False)
    , (CPat "And" [VPat "l", VPat "r"],
            apps (ref "and")
            [ ev (ref "l"), ev (ref "r") ])
    , (CPat "Or" [VPat "l", VPat "r"],
            apps (ref "or")
            [ ev (ref "l"), ev (ref "r") ])
    , (CPat "If" [VPat "c", VPat "t", VPat "e"],
            Cond (ev (ref "c")) (ev (ref "t")) (ev (ref "e")))
    ]

arithEvalCases :: (Expr -> Expr) -> [Branch]
arithEvalCases ev =
    [ (CPat "Lit" [ VPat "n" ], ref "n")
    , (CPat "Plus" [ VPat "l", VPat "r" ],
        BinOp Plus (ev (ref "l")) (ev (ref "r")))
    , (CPat "Times" [ VPat "l", VPat "r" ],
        BinOp Times (ev (ref "l")) (ev (ref "r")))
    ]

nthElemBody :: Decl
nthElemBody =
    let_ "nthElem" $ abs_ "i" $ abs_ "l" $
        case_ (ref "l")
            [ (CPat "Cons" [ VPat "x", VPat "xs" ],
                case_ (ref "i")
                    [ (IPat 0, (ref "x"))
                    , (VPat "n", apps (ref "nthElem")
                        [ BinOp Minus (ref "n") (icon 1), ref "xs" ])
                    ])
            ]

absEvalCases :: String -> (Expr -> Expr -> Expr) -> [Branch]
absEvalCases s ev =
    [ (CPat "Abs" [VPat "e"], (ref "e"))
    , (CPat "App" [VPat "l", VPat "r"],
        ev (apps (dcon "Cons") [ ev (ref s) (ref "r"), ref s ]) (ev (ref s) (ref "l")))
    , (CPat "Var" [VPat "i"],
        apps (ref "nthElem") [ ref "i", ref s])
    ]

boolEvalBody :: Decl
boolEvalBody =
    let_ "eval" $ abs_ "e" $ case_ (ref "e") $ boolEvalCases (app (ref "eval"))

arithEvalBody :: Decl
arithEvalBody =
    let_ "eval" $ abs_ "e" $ case_ (ref "e") $
        boolEvalCases eval ++ arithEvalCases eval
    where eval = app (ref "eval")

absEvalBody :: Decl
absEvalBody =
    let_ "eval" $ abs_ "s" $ abs_ "e" $ case_ (ref "e") $
        boolEvalCases shortEval ++ arithEvalCases shortEval ++ absEvalCases "s" eval
    where
        eval s e = apps (ref "eval") [ s, e ]
        shortEval = eval (ref "s")

constantFoldBody :: Decl
constantFoldBody =
    let_ "constantFold" $ abs_ "e" $ case_ (ref "e") $
        [ (CPat "Plus" [ VPat "l", VPat "r" ],
            case_ (apps (dcon "(,)") [ rec "l", rec "r" ]) $
                [ ( CPat "(,)" [ CPat "Lit" [ VPat "x" ], CPat "Lit" [ VPat "y" ] ]
                  , app (dcon "Lit") (binop Plus (ref "x") (ref "y"))
                  )
                , ( CPat "(,)" [ VPat "lf", VPat "rf" ]
                  , apps (dcon "Plus") [ ref "lf", ref "rf" ]
                  )
                ])
        , (CPat "Times" [ VPat "l", VPat "r" ],
            case_ (apps (dcon "(,)") [ rec "l", rec "r" ]) $
                [ ( CPat "(,)" [ CPat "Lit" [ VPat "x" ], CPat "Lit" [ VPat "y" ] ]
                  , app (dcon "Lit") (binop Times (ref "x") (ref "y"))
                  )
                , ( CPat "(,)" [ VPat "lf", VPat "rf" ]
                  , apps (dcon "Times") [ ref "lf", ref "rf" ]
                  )
                ])
        , (CPat "And" [ VPat "l", VPat "r" ],
            apps (dcon "And") [ rec "l", rec "r" ])
        , (CPat "Or" [ VPat "l", VPat "r" ],
            apps (dcon "Or") [ rec "l", rec "r" ])
        , (CPat "If" [ VPat "c", VPat "t", VPat "el" ],
            apps (dcon "If") [ rec "c", rec "t", rec "el" ])
        , (CPat "App" [ VPat "l", VPat "r" ],
            apps (dcon "App") [ rec "l", rec "r" ])
        , (CPat "Abs" [ VPat "x", VPat "ep" ],
            apps (dcon "Abs") [ ref "x", rec "ep" ])
        , (VPat "x", ref "x")
        ]
    where rec = app (ref "constantFold") . ref

typecheckBody :: Decl
typecheckBody =
    let_ "typecheck" $ abs_ "e" $ case_ (ref "e") $
        [ (CPat "Plus" [VPat "l", VPat "r"], case_ (mkPair (rec "l") (rec "r")) $
            [ (pairPat (CPat "TInt" []) (CPat "TInt" []), dcon "TInt")
            , (VPat "otherwise", dcon "TErr")
            ])
        , (CPat "Times" [VPat "l", VPat "r"], case_ (mkPair (rec "l") (rec "r")) $
            [ (pairPat (CPat "TInt" []) (CPat "TInt" []), dcon "TInt")
            , (VPat "otherwise", dcon "TErr")
            ])
        , (CPat "Lit" [VPat "x"], dcon "TInt")
        , (CPat "And" [VPat "l", VPat "r"], case_ (mkPair (rec "l") (rec "r")) $
            [ (pairPat (CPat "TBool" []) (CPat "TBool" []), dcon "TBool")
            , (VPat "otherwise", dcon "TErr")
            ])
        , (CPat "Or" [VPat "l", VPat "r"], case_ (mkPair (rec "l") (rec "r")) $
            [ (pairPat (CPat "TBool" []) (CPat "TBool" []), dcon "TBool")
            , (VPat "otherwise", dcon "TErr")
            ])
        , (CPat "If" [VPat "c", VPat "t", VPat "el"], case_ (mkTriple (rec "c") (rec "t") (rec "el")) $
            [ (triplePat (CPat "TBool" []) (CPat "TBool" []) (CPat "TBool" []), dcon "TBool")
            , (triplePat (CPat "TBool" []) (CPat "TInt" []) (CPat "TInt" []), dcon "TInt")
            , (VPat "otherwise", dcon "TErr")
            ])
        , (CPat "True" [], dcon "TBool")
        , (CPat "False" [], dcon "TBool")
        ]
    where
        rec = app (ref "typecheck") . ref

constantsBody :: Decl
constantsBody = let_ "constants" $ abs_ "e" $ case_ (ref "e")
    [ (CPat "Plus" [VPat "l", VPat "r"],
        apps (ref "concat") [ rec "l", rec "r" ])
    , (CPat "Times" [VPat "l", VPat "r"],
        apps (ref "concat") [ rec "l", rec "r" ])
    , (CPat "Lit" [VPat "x"], genList [ ref "x" ])
    , (CPat "And" [VPat "l", VPat "r"],
        apps (ref "concat") [ rec "l", rec "r" ])
    , (CPat "Or" [VPat "l", VPat "r"],
        apps (ref "concat") [ rec "l", rec "r" ])
    , (CPat "If" [VPat "c", VPat "t", VPat "el"],
        apps (ref "concat")
            [ rec "c"
            , apps (ref "concat") [ rec "t", rec "el" ]
            ])
    , (CPat "App" [VPat "l", VPat "r"],
        apps (ref "concat") [ rec "l", rec "r" ])
    , (CPat "Abs" [VPat "x", VPat "el"], rec "el")
    , (VPat "x", genList [])
    ]
    where rec = app (ref "constants") . ref

mkPair :: Expr -> Expr -> Expr
mkPair l r = apps (dcon "(,)") [l, r]

mkTriple :: Expr -> Expr -> Expr -> Expr
mkTriple a b c = apps (dcon "Triple") [a, b, c]

pairPat :: Pat -> Pat -> Pat
pairPat l r = CPat "(,)" [ l, r]

triplePat :: Pat -> Pat -> Pat -> Pat
triplePat a b c = CPat "Triple" [ a, b, c]

mex1 :: Expr
mex1 = apps (dcon "If") [ dcon "True", dcon "False", dcon "True" ]

mex2 :: Expr
mex2 = apps (dcon "If") [ mex1, dcon "False", dcon "True" ]

mex3 :: Expr
mex3 = app (dcon "Lit") (icon 1)

mex4 :: Expr
mex4 = apps (dcon "If")
    [ mex2
    , apps (dcon "Plus") [ app (dcon "Lit") (icon 3), app (dcon "Lit") (icon 7) ]
    , mex3
    ]

mex5 :: Expr
mex5 = app (dcon "Abs") (apps (dcon "Plus") [ app (dcon "Lit") (icon 1), app (dcon "Var") (icon 0) ])

mex6 :: Expr
mex6 = apps (dcon "App") [ mex5, apps (dcon "App") [ mex5, app (dcon "Lit") (icon 1) ] ]

boolProg :: Expr -> Prog
boolProg = prog [andBody, orBody, boolEvalBody] . app (ref "eval")

arithProg :: Expr -> Prog
arithProg = prog [andBody, orBody, arithEvalBody] . app (ref "eval")

absProg :: Expr -> Prog
absProg = prog [andBody, orBody, absEvalBody, nthElemBody] . app (app (ref "eval") (dcon "Nil"))

constantFoldProg :: Expr -> Prog
constantFoldProg = prog [constantFoldBody] . app (ref "constantFold")

typecheckProg :: Expr -> Prog
typecheckProg = prog [typecheckBody] . app (ref "typecheck")

constantsProg :: Expr -> Prog
constantsProg = prog [concatBody, constantsBody] . app (ref "constants")

revBody :: Decl
revBody = let_ "rev" $ abs_ "l" $ case_ (ref "l")
    [ (CPat "Nil" [], dcon "Nil")
    , (CPat "Cons" [VPat "x", VPat "xs"],
        apps (ref "concat") [ app (ref "rev") (ref "xs"), genList [ ref "x" ] ])
    ]

revProg :: Prog
revProg = prog [concatBody, revBody] $ app (ref "rev") $ genIlist [1,2,3,4]

revAccBody :: Decl
revAccBody = let_ "revAcc" $ abs_ "a" $ abs_ "l" $ case_ (ref "l")
    [ (CPat "Nil" [], ref "a")
    , (CPat "Cons" [VPat "x", VPat "xs"],
        apps (ref "revAcc") [ apps (dcon "Cons") [ref "x", ref "a"], ref "xs" ])
    ]

revAccProg :: Prog
revAccProg = prog [revAccBody] $ apps (ref "revAcc") [ dcon "Nil", genIlist [1,2,3,4] ]

crossBody :: Decl
crossBody = let_ "cross" $ abs_ "l"  $ abs_ "m" $ case_ (ref "l")
    [ (CPat "Cons" [VPat "x", VPat "xs"],
        apps (ref "concat")
            [ apps (ref "map") [ app (dcon "(,)") (ref "x"), ref "m" ]
            , apps (ref "cross") [ ref "xs", ref "m" ]
            ])
    , (CPat "Nil" [], dcon "Nil")
    ]

crossProg :: Prog
crossProg = prog [concatBody, mapBody, crossBody] $
    apps (ref "cross") [ genIlist [1,2], genIlist [1,2] ]

replicateBody :: Decl
replicateBody = let_ "replicate" $ abs_ "n" $ abs_ "x" $ case_ (ref "n")
    [ (IPat 0, dcon "Nil")
    , (VPat "m", apps (dcon "Cons") [ ref "x", apps (ref "replicate") [ binop Minus (ref "n") (icon 1), ref "x" ] ])
    ]

replicateProg :: Prog
replicateProg = prog [replicateBody] $ apps (ref "replicate") [ icon 5, icon 1 ]

{-| Generates a series of applications of a function
 -  to the given list of values.
 -}
apps :: Expr -> [Expr] -> Expr
apps fun [x     ] = app fun x
apps fun (x : xs) = apps (app fun x) xs
apps _   []       = undefined

exEvenFilter :: Prog
exEvenFilter =
  prog [evenBody, filterBody] $ app (app (ref "filter") (ref "even")) $ genIlist
    [2, 0]

-- BinOp examples
ex1 :: Expr
ex1 = binop Plus (icon 2) (binop Plus (icon 2) (icon 3))

ex2 :: Expr
ex2 = binop Plus (icon 2) (dcon "Cons")

ex3 :: Expr
ex3 = binop Plus (icon 2) (ref "a")

e1 :: Expr
e1 = app (abs_ "x" (binop Plus (ref "x") (icon 2))) (icon 2)

e2 :: Expr
e2 = app (abs_ "x" (icon 2)) (icon 3)

e3 :: Expr
e3 =
  app (abs_ "x" (case_ (ref "x") [(IPat 0, icon 1), (IPat 1, icon 0)])) (icon 1)

e4 :: Expr
e4 = app (abs_ "x" (case_ (ref "x") [(VPat "n", icon 1), (IPat 1, icon 0)]))
         (icon 1)

e5 :: Expr
e5 = case_
  (icon 0)
  [((VPat "n"), (app (abs_ "x" (binop Plus (ref "x") (icon 2))) (ref "n")))]

e6 :: Expr
e6 = case_ (app (dcon "Wrap") (icon 3)) [(CPat "Wrap" [VPat "n"], ref "n")]

e7 :: Expr
e7 = binop
  Plus
  (app (abs_ "x" (binop Plus (icon 1) (ref "x"))) (icon 5))
  (binop
    Plus
    (icon 1)
    (app
      (abs_
        "x"
        (binop Plus
               (icon 0)
               (binop Plus (icon 1) (binop Plus (icon 1) (ref "x")))
        )
      )
      (icon 5)
    )
  )

e8 :: Expr
e8 = case_ (app (dcon "Wrap") (icon 3)) [(VPat "w", ref "w")]

e9 :: Expr
e9 = case_ (app (dcon "Wrap") (icon 3)) [(CPat "Wrap" [VPat "n"], icon 3)]

e10 :: Expr
e10 = app
  (app
    (abs_ "x" (abs_ "y" (binop Plus (ref "x") (binop Plus (ref "x") (ref "x"))))
    )
    (icon 1)
  )
  (icon 2)

e11 :: Expr
e11 =
  binop
      Plus
      (let_ "x" (icon 1) (binop Plus (icon 2) (binop Plus (ref "x") (icon 3))))
    $ let_ "x" (icon 1) (binop Plus (ref "x") (icon 3))

e12 :: Expr
e12 =
  binop Plus (let_ "x" (icon 1) (binop Plus (ref "x") (icon 3)))
    $ (let_ "x" (icon 1) (binop Plus (icon 2) (binop Plus (ref "x") (icon 3))))

e13 :: Expr
e13 =
  binop
      Plus
      (let_ "x"
            (binop Plus (icon 2) (icon 3))
            (binop Plus (icon 3) (binop Plus (icon 2) (icon 3)))
      )
    $ let_ "x" (icon 1) (binop Plus (ref "x") (icon 3))

e14 :: Expr
e14 = let_
  "x"
  (icon 1)
  (let_ "x" (binop Plus (ref "x") (icon 2)) (binop Plus (ref "x") (icon 2)))
--let flist = \gs->\x->case gs of {[]->[]; f:fs->f x:flist fs x}
--in flist [sqr,fact] 2

e15 :: Expr
e15 =
  let_
      "flist"
      (abs_
        "gs"
        (abs_
          "x"
          (case_
            (ref "gs")
            [ (CPat "Nil" [], dcon "Nil")
            , ( CPat "Cons" [VPat "f", VPat "fs"]
              , app (app (dcon "Cons") (app (ref "f") (ref "x")))
                    (apps (ref "flist") [ref "fs", ref "x"])
              )
            ]
          )
        )
      )
    $ app (app (ref "flist") (genList [ref "sqr", ref "fact"]))
    $ icon 2
--let plus = \x->\y->x+y in
--let suc = plus 1 in
 --suc 3
e16 :: Expr
e16 =
  let_ "plus" (abs_ "x" $ abs_ "y" $ binop Plus (ref "x") $ ref "y")
    $ let_ "suc" (app (ref "plus") $ icon 1)
    $ app (ref "suc")
    $ icon 3

e17 :: Expr
e17 =
  let_ "plus" (abs_ "x" $ abs_ "y" $ binop Plus (ref "x") $ ref "y")
    $ let_ "suc" (app (ref "plus") $ icon 1)
    $ binop Plus (app (ref "suc") $ icon 3)
    $ app (ref "suc")
    $ icon 4

e18 :: Expr
e18 =
  let_
      "applyF"
      ( abs_ "f"
      $ abs_ "x"
      $ binop Plus (app (ref "f") (ref "x"))
      $ app (ref "f")
      $ app (ref "f") (ref "x")
      )
    $ app (app (ref "applyF") (ref "sqr"))
    $ icon 2

--let foo = \f->\x->f x+(3+f (x*x)) in
--let suc = \x->x+1 in
-- foo suc 1
e19 :: Expr
e19 =
  let_
      "foo"
      ( abs_ "f"
      $ abs_ "x"
      $ binop Plus (app (ref "f") (ref "x"))
      $ binop Plus (icon 3)
      $ app (ref "f")
      $ binop Times (ref "x")
      $ ref "x"
      )
    $ let_ "suc" (abs_ "x" $ binop Plus (ref "x") $ icon 1)
    $ app (app (ref "foo") (ref "suc"))
    $ icon 1

e20 :: Expr
e20 =
  binop Plus (app (ref "sqr") (icon 3))
    $ app (ref "sqr")
    $ app (ref "sqr")
    $ icon 3

e21 :: Expr
e21 =
  binop
      Plus
      (let_ "x" (icon 1) (binop Plus (binop Plus (ref "x") (icon 1)) $ icon 1))
    $ let_ "x" (icon 1)
    $ binop Plus (ref "x") (icon 1)

sumList :: Expr
sumList =
  let_
      "sum"
      (abs_ "l" $ case_
        (ref "l")
        [ (CPat "Nil" [], icon 0)
        , ( CPat "Cons" [VPat "x", VPat "xs"]
          , binop Plus (ref "x") (app (ref "sum") (ref "xs"))
          )
        ]
      )
    $ app (ref "sum")
    $ genIlist [1 .. 10]
sumProg :: Prog
sumProg = Prog $ sumList

e22 :: Expr
e22 =
  let_ "x" (icon 1)
    $ let_ "x" (binop Plus (ref "x") (icon 1))
    $ (binop Times (icon 2) (ref "x"))
--let subsets = \s->case s of {[] -> []; x:xs -> let s = subsets xs in s++map (x:) s}
--in subsets [2,3,4]

flawed_subsetBody :: Expr
flawed_subsetBody =
  let_
      "subsets"
      (abs_ "s" $ case_
        (ref "s")
        [ (CPat "Nil" [], dcon "Nil")
        , ( CPat "Cons" [VPat "x", VPat "xs"]
          , let_ "s" (app (ref "subsets") (ref "xs"))
          $ app (app (ref "concat") (ref "s"))
          $ app (app (ref "map") (app (dcon "Cons") (ref "x"))) (ref "s")
          )
        ]
      )
    $ app (ref "subsets")
    $ genIlist [2, 3, 4]

flawed_subsetProg :: Prog
flawed_subsetProg = prog [concatBody, mapBody] $ flawed_subsetBody

subsetBody :: Expr
subsetBody =
  let_
      "subsets"
      (abs_ "s" $ case_
        (ref "s")
        [ (CPat "Nil" [], genList [dcon "Nil"])
        , ( CPat "Cons" [VPat "x", VPat "xs"]
          , let_ "s" (app (ref "subsets") (ref "xs"))
          $ app (app (ref "concat") (ref "s"))
          $ app (app (ref "map") (app (dcon "Cons") (ref "x"))) (ref "s")
          )
        ]
      )
    $ app (ref "subsets")
    $ genIlist [2, 3, 4]

subsetProg :: Prog
subsetProg = prog [concatBody, mapBody] $ subsetBody


minValueBody :: Decl
minValueBody = let_ "minValue" (icon 3)

greaterThanBody :: Decl
greaterThanBody =
  let_ "greaterThan" $ abs_ "x" $ abs_ "y" $ binop Gt (ref "y") (ref "x")

minValueProg :: Prog
minValueProg =
  prog [minValueBody, filterBody, greaterThanBody]
    $ app (app (ref "filter") (app (ref "greaterThan") (ref "minValue")))
    $ genIlist [1, 2, 4]

pairEx :: Expr
pairEx =
  app (app (dcon "(,)") (app (ref "sqr") (icon 2))) $ app (ref "sqr") (icon 2)

secondBody :: Decl
secondBody = let_ "second" $ abs_ "f" $ abs_ "p" $ case_
  (ref "p")
  [ ( CPat "(,)" [VPat "a", VPat "b"]
    , (app (app (dcon "(,)") (ref "a")) (app (ref "f") (ref "b")))
    )
  ]

secondProg :: Prog
secondProg =
  prog [secondBody, squareBody] $ app (app (ref "second") (ref "sqr")) pairEx

{-Twice function
-}
twiceBody :: Decl
twiceBody =
  let_ "twice" $ abs_ "f" $ abs_ "x" $ app (ref "f") $ app (ref "f") (ref "x")

factPlusProg :: Prog
factPlusProg = prog [twiceBody, factBody]
  $ binop Plus (app (ref "fact") (icon 2)) (app (ref "fact") (icon 3))

lengthPlusProg :: Prog
lengthPlusProg =
  prog [lenBody] $ binop Plus (app (ref "length") (genIlist [5])) $ app
    (ref "length")
    (genIlist [6, 5])

oneFactProg :: Prog
oneFactProg = prog [twiceBody, factBody] $ binop Plus (icon 1) $ binop
  Plus
  (app (ref "fact") (icon 2))
  (app (ref "fact") (icon 3))

twiceProg :: Prog
twiceProg =
  prog [twiceBody, factBody] $ app (app (ref "twice") (ref "fact")) (icon 2)

twiceProg' :: Prog
twiceProg' =
  prog [twiceBody, squareBody] $ app (app (ref "twice") (ref "sqr")) (icon 1)

sqrPlusProg :: Prog
sqrPlusProg = prog [squareBody] $ binop
  Plus
  (app (ref "sqr") (icon 3))
  (binop Plus (app (ref "sqr") (icon 2)) (app (ref "sqr") (icon 3)))

{-Compose function
-}
composeBody :: Decl
composeBody =
  let_ "compose" $ abs_ "f" $ abs_ "g" $ abs_ "x" $ app (ref "f") $ app
    (ref "g")
    (ref "x")

{-Double function
-}
doubleBody :: Decl
doubleBody =
  let_ "double"
    $ abs_ "f"
    $ abs_ "x"
    $ binop Plus (app (ref "f") (ref "x"))
    $ app (ref "f")
    $ ref "x"

doubleProg :: Prog
doubleProg =
  prog [doubleBody, squareBody] $ app (app (ref "double") (ref "sqr")) (icon 2)

{- Map function.
 -}
mapBody :: Decl
mapBody = let_ "map" $ abs_ "f" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], dcon "Nil")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , app (app (dcon "Cons") (app (ref "f") (ref "x")))
          (apps (ref "map") [ref "f", ref "xs"])
    )
  ]

{- Concat -}
concatBody :: Decl
concatBody = let_ "concat" $ abs_ "l" $ abs_ "r" $ case_
  (ref "l")
  [ (CPat "Nil" [], ref "r")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , app (app (dcon "Cons") (ref "x"))
          (app (app (ref "concat") (ref "xs")) (ref "r"))
    )
  ]

{- Not -}
notBody :: Decl
notBody = let_ "not" $ abs_ "b" $ case_
  (ref "b")
  [(BPat True, bcon False), (BPat False, bcon True)]

{- Quicksort -}
quicksortBody :: Decl
quicksortBody =
  let_ "quicksort"
    $ abs_ "list"
    $ case_ (ref "list")
    $ [ (CPat "Nil" [], (ref "list"))
      , ( CPat "Cons" [VPat "pivot", VPat "xs"]
        , apps
          (ref "concat")
          [ app
            (ref "quicksort")
            ( apps (ref "filter") [app (ref "leq") (ref "pivot"), ref "xs"] )
          , apps
            (dcon "Cons")
            [ ref "pivot"
            , app
              (ref "quicksort")
              ( apps (ref "filter") [ app (ref "gt") (ref "pivot"), ref "xs" ] )
            ]
          ]
        )
      ]

{- Filter function.
 -}
filterBody :: Decl
filterBody = let_ "filter" $ abs_ "f" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], dcon "Nil")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , case_
      (app (ref "f") (ref "x"))
      [ (BPat False, app (app (ref "filter") (ref "f")) (ref "xs"))
      , ( BPat True
        , app (app (dcon "Cons") (ref "x"))
              (app (app (ref "filter") (ref "f")) (ref "xs"))
        )
      ]
    )
  ]

terribleAddBody :: Decl
terribleAddBody = let_ "tadd" $ abs_ "x" $ abs_ "y" $ case_
  (ref "x")
  [ (IPat 0, ref "y")
  , ( VPat "n"
    , binop Plus
            (icon 1)
            (apps (ref "tadd") [binop Minus (ref "n") (icon 1), (ref "y")])
    )
  ]

sumFsBody :: Decl
sumFsBody = let_ "sfs" $ abs_ "f" $ abs_ "x" $ case_
  (ref "x")
  [ (IPat 0, icon 0)
  , ( VPat "n"
    , binop Plus
            (app (ref "f") (ref "x"))
            (apps (ref "sfs") [ref "f", binop Minus (ref "x") (icon 1)])
    )
  ]

genFsBody :: Decl
genFsBody = let_ "gfs" $ abs_ "f" $ abs_ "x" $ case_
  (ref "x")
  [ (IPat 0, icon 0)
  , ( VPat "n"
    , apps
      (dcon "Cons")
      [ app (ref "f") (ref "x")
      , apps (ref "gfs") [ref "f", binop Minus (ref "x") (icon 1)]
      ]
    )
  ]

addNBody :: Decl
addNBody = let_ "addn" $ abs_ "n" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], dcon "Nil")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , apps
      (dcon "Cons")
      [binop Plus (ref "x") (ref "n"), apps (ref "addn") [ref "n", ref "xs"]]
    )
  ]

doNothingBody :: Decl
doNothingBody = let_ "donot" $ abs_ "f" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], dcon "Nil")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , apps (dcon "Cons") [ref "x", apps (ref "donot") [ref "f", ref "xs"]]
    )
  ]

transformFirstBody :: Decl
transformFirstBody = let_ "tfirst" $ abs_ "f" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" []                    , app (ref "f") (icon 0))
  , (CPat "Cons" [VPat "x", VPat "xs"], app (ref "f") (ref "x"))
  ]

{-| Square function.
 -}
squareBody :: Decl
squareBody = let_ "sqr" $ abs_ "n" $ binop Times (ref "n") (ref "n")

{-| Even function.
 -}
evenBody :: Decl
evenBody = let_ "even" $ abs_ "n" $ case_
  (binop Mod (ref "n") (icon 2))
  [(IPat 0, bcon True), (VPat "x", bcon False)]

{-| "less than or equal" function
 -}
leqBody :: Decl
leqBody = let_ "leq" $ abs_ "n" $ abs_ "m" $ apps (ref "geq") [ref "n", ref "m"]

{-| "greater than or equal to" function
 -}
geqBodyBroken :: Decl
geqBodyBroken = let_ "geq" $ abs_ "n" $ abs_ "m" $ cond
  (binop Gt (ref "n") (ref "m"))
  (bcon True)
  (bcon False)

geqBody :: Decl
geqBody = let_ "geq" $ abs_ "n" $ abs_ "m" $ (apps (ref "or")
  [binop Gt (ref "n") (ref "m")
  ,apps (ref "eq") [ref "n", ref "m"]])

equalBody :: Decl
equalBody = let_ "eq" $ abs_ "x" $ abs_ "y" $ app (ref "not") (apps (ref "or") [binop Gt (ref "x") (ref "y") ,binop Gt (ref "y") (ref "x")])

equalTest :: Prog
equalTest = prog [geqBody, equalBody, notBody, orBody] $ apps (ref "geq") [icon 2, icon 1]


{-| Drop function.
 -}
dropBody :: Decl
dropBody = let_ "drop" $ abs_ "n" $ abs_ "l" $ case_
  (ref "n")
  [ (IPat 0, ref "l")
  , ( VPat "n"
    , case_
      (ref "l")
      [ (CPat "Nil" [], dcon "Nil")
      , ( CPat "Cons" [VPat "x", VPat "xs"]
        , app (app (ref "drop") (binop Minus (ref "n") (icon 1))) (ref "xs")
        )
      ]
    )
  ]

{-| Take function.
 -}
takeBody :: Decl
takeBody = let_ "take" $ abs_ "n" $ abs_ "l" $ case_
  (ref "n")
  [ (IPat 0, genIlist [])
  , ( VPat "n"
    , case_
      (ref "l")
      [ (CPat "Nil" [], dcon "Nil")
      , ( CPat "Cons" [VPat "x", VPat "xs"]
        , app
          (app (dcon "Cons") (ref "x"))
          (app (app (ref "take") (binop Minus (ref "n") (icon 1))) (ref "xs"))
        )
      ]
    )
  ]

{-| Merge function.
 -}
mergeBody :: Decl
mergeBody = let_ "merge" $ abs_ "l1" $ abs_ "l2" $ case_
  (ref "l1")
  [ (CPat "Nil" [], ref "l2")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , case_
      (ref "l2")
      [ (CPat "Nil" [], ref "l1")
      , ( CPat "Cons" [VPat "y", VPat "ys"]
        , cond
          (binop Gt (ref "y") (ref "x"))
          (app (app (dcon "Cons") (ref "x"))
               (app (app (ref "merge") (ref "xs")) $ ref "l2")
          )
          (app (app (dcon "Cons") (ref "y"))
               (app (app (ref "merge") (ref "l1")) $ ref "ys")
          )
        )
      ]
    )
  ]

{-| Merge sort function.
 -}
mergesortBody :: Decl
mergesortBody = let_ "mergesort" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], dcon "Nil")
  , (CPat "Cons" [VPat "x", CPat "Nil" []], ref "l")
  , (VPat "l", apps (ref "merge") [sortCall takeExpr, sortCall dropExpr])
  ]
 where
  listLength = app (ref "length") (ref "l")
  halfLength = binop Div listLength (icon 2)
  sortCall   = app (ref "mergesort")
  takeExpr   = app (app (ref "take") halfLength) (ref "l")
  dropExpr   = app (app (ref "drop") halfLength) (ref "l")

{-| Reduce function (foldr).
 -}
reduceBody :: Decl
reduceBody = let_ "reduce" $ abs_ "f" $ abs_ "l" $ abs_ "z" $ case_
  (ref "l")
  [ (CPat "Nil" [], ref "z")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , apps (ref "f") [ref "x", apps (ref "reduce") [ref "f", ref "xs", ref "z"]]
    )
  ]

{-| Add function.
 -}
addBody :: Decl
addBody = let_ "add" $ abs_ "x" $ abs_ "y" $ binop Plus (ref "x") (ref "y")

{-| Multiply function.
 -}
multBody :: Decl
multBody = let_ "mult" $ abs_ "x" $ abs_ "y" $ binop Times (ref "x") (ref "y")

{- Factorial function.
 -}
factBody :: Decl
factBody = let_ "fact" $ abs_ "x" $ case_
  (ref "x")
  [ (IPat 0, icon 1)
  , ( VPat "y"
    , binop Times (ref "x") (app (ref "fact") $ binop Minus (ref "x") (icon 1))
    )
  ]

{-| Length function.
 -}
lenBody :: Decl
lenBody = let_ "length" $ abs_ "l" $ case_
  (ref "l")
  [ ( CPat "Cons" [VPat "x", VPat "xs"]
    , binop Plus (icon 1) (app (ref "length") (ref "xs"))
    )
  , (CPat "Nil" [], icon 0)
  ]

{-| "first value of tuple" function
 -}
fstBody :: Decl
fstBody = let_ "fst" $ abs_ "p" $ case_
  (ref "p")
  [(CPat "P" [VPat "x", VPat "y"], ref "x")]

{-| "second value of tuple" function
 -}
sndBody :: Decl
sndBody = let_ "snd" $ abs_ "p" $ case_
  (ref "p")
  [(CPat "P" [VPat "x", VPat "y"], ref "y")]

{-| A constant function that just has the left constructor.
 -}
leftBody :: Decl
leftBody = let_ "left" $ app (dcon "Left") (icon 1)

{-| A constant function that just has the right constructor.
 -}
rightBody :: Decl
rightBody = let_ "right" $ app (dcon "Right") (icon 0)

{-| Function to unwrap an "Either" value.
 -}
leftOrRightBody :: Decl
leftOrRightBody = let_ "leftOrRight" $ abs_ "x" $ case_
  (ref "x")
  [(CPat "Left" [VPat "l"], ref "l"), (CPat "Right" [VPat "r"], ref "r")]

{-| Function to insert a number into a sorted list.
 -}
insertSortedBody :: Decl
insertSortedBody = let_ "insertSorted" $ abs_ "x" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], apps (dcon "Cons") [ref "x", dcon "Nil"])
  , ( CPat "Cons" [VPat "y", VPat "ys"]
    , cond
      (binop Gt (ref "y") (ref "x"))
      (apps (dcon "Cons") [ref "x", ref "l"])
      (apps (dcon "Cons")
            [ref "y", apps (ref "insertSorted") [ref "x", ref "ys"]]
      )
    )
  ]

{-| Insertion sort function.
 -}
insertionSortBody :: Decl
insertionSortBody = let_ "insertionSort" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], dcon "Nil")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , apps (ref "insertSorted") [ref "x", app (ref "insertionSort") (ref "xs")]
    )
  ]

{-| Min Function
-}
minBody :: Decl
minBody = let_ "min" $ abs_ "l" $ case_
  (ref "l")
  [(CPat "Cons" [VPat "x", VPat "xs"], apps (ref "minE") [ref "x", ref "xs"])]

minEBody :: Decl
minEBody = let_ "minE" $ abs_ "m" $ abs_ "l" $ case_
  (ref "l")
  [ (CPat "Nil" [], ref "m")
  , ( CPat "Cons" [VPat "x", VPat "xs"]
    , cond (binop Gt (ref "m") (ref "xs"))
           (apps (ref "minE") [ref "x", ref "xs"])
           (apps (ref "minE") [ref "m", ref "xs"])
    )
  ]

{-| Expression using the "map" function.
 -}
mapEx :: Expr
mapEx = app (app (ref "map") (ref "sqr")) (genIlist [1, 2, 3])

{-| Program that uses the "map" function.
 -}
mapProg :: Prog
mapProg = prog [mapBody, squareBody] mapEx

concatEx :: Expr
concatEx = apps (ref "concat") [genIlist [1, 2, 3], genIlist [4, 5, 6]]

concatProg :: Prog
concatProg = prog [concatBody] concatEx

quicksortEx :: Expr
quicksortEx = app
  (ref "quicksort")
  (genIlist [2,4,2,1,3])

quicksortProg :: Prog
quicksortProg =
  prog [orBody, notBody, equalBody, geqBody, leqBody, gtBody, ltBody, filterBody, concatBody, quicksortBody] quicksortEx
  where
    gtBody = let_ "gt" $ abs_ "x" $ abs_ "y" $ binop Gt (ref "y") (ref "x")
    ltBody = let_ "lt" $ abs_ "x" $ abs_ "y" $ binop Gt (ref "x") (ref "y")

{-| Expression using the "filter" function.
 -}
filterEx :: Expr
filterEx = app (app (ref "filter") (ref "even")) (genIlist [1, 2, 3, 4])

{-| Program using the "filter" function.
 -}
filterProg :: Prog
filterProg = prog [filterBody, evenBody] filterEx

{-| An expression using the "reduce" function.
 -}
reduceEx :: Expr
reduceEx =
  app (app (app (ref "reduce") (ref "add")) (genIlist [1, 2, 3])) (icon 0)

{-| A program using the "reduce" function.
 -}
reduceProg :: Prog
reduceProg = prog [reduceBody, addBody] reduceEx

{-| A function that generates an expression to "reduce" a
 -  given list of integers.
 -}
reduceExList :: [Int] -> Expr
reduceExList xs =
  app (app (app (ref "reduce") (ref "add")) (genIlist xs)) (icon 0)

{-| A function that generates a program to "reduce" a
 -  given list of integers.
 -}
reduceProgList :: [Int] -> Prog
reduceProgList = prog [reduceBody, addBody] . reduceExList

{-| An expression that uses the "factorial" function.
 -}
factEx :: Expr
factEx = app (ref "fact") (icon 6)

{-| A program that uses the "factorial" function.
 -}
factProg :: Prog
factProg = prog [factBody] factEx

{-| A function that creates an expression for a
 -  factorial of a given integer.
 -}
factExInt :: Int -> Expr
factExInt = app (ref "fact") . icon

{-| A function that creates a program for a
 -  factorial of a given integer.
 -}
factProgInt :: Int -> Prog
factProgInt = prog [factBody] . factExInt

bindingEx :: Expr
bindingEx = app (let_ "x" (icon 1) (abs_ "n" (binop Plus (ref "x") (ref "n")))) (icon 5)

bindingProg :: Prog
bindingProg = prog [] bindingEx

{-| An expression that uses the "leftOrRight" function on a "left" value.
 -}
leftEx :: Expr
leftEx = binop Plus (icon 1) (app (ref "leftOrRight") (ref "left"))

{-| A program that uses the "leftOrRight" function on a "left" value.
 -}
leftProg :: Prog
leftProg = prog [leftOrRightBody, leftBody, rightBody] leftEx

{-| An expression that uses the "leftOrRight" function on a "right" value.
 -}
rightEx :: Expr
rightEx = binop Plus (icon 1) (app (ref "leftOrRight") (ref "right"))

{-| A program that uses the "leftOrRight" function on a "right" value.
 -}
rightProg :: Prog
rightProg = prog [leftOrRightBody, leftBody, rightBody] rightEx

{-| An expression that uses the "length" function.
 -}
lenEx :: Expr
lenEx = app (ref "length") $ genIlist [1, 2, 5, 9, 13]

{-| A program that uses the "length" function.
 -}
lenProg :: Prog
lenProg = prog [lenBody] lenEx

{-| A function that creates an expression that applies the "length"
 - function to a given list of integers.
 -}
lenExList :: [Int] -> Expr
lenExList = app (ref "length") . genIlist

{-| A function that creates a program that applies the "length"
 - function to a given list of integers.
 -}
lenProgList :: [Int] -> Prog
lenProgList = prog [lenBody] . lenExList

{-| An expression that uses the "merge" function.
 -}
mergeEx :: Expr
mergeEx = app (app (ref "merge") (genIlist [0, 3, 2])) (genIlist [1, 1, 2])

{-| A program that uses the "merge" function.
 -}
mergeProg :: Prog
mergeProg = prog [mergeBody] mergeEx

{-| An expression that uses the "drop" function.
 -}
dropEx :: Expr
dropEx = app (app (ref "drop") (icon 3)) (genIlist [0, 1, 2, 3, 4, 5, 6])

{-| A program that uses the "drop" function.
 -}
dropProg :: Prog
dropProg = prog [dropBody] dropEx

{-| An expression that uses the "take" function.
 -}
takeEx :: Expr
takeEx = app (app (ref "take") (icon 3)) (genIlist [0, 1, 2, 3, 4, 5, 6])

{-| A program that uses the "take" function.
 -}
takeProg :: Prog
takeProg = prog [takeBody] takeEx

{-| An expression that uses the "mergesort" function.
 -}
mergesortEx :: Expr
mergesortEx = app (ref "mergesort") $ genIlist [0, 2, 1, 4, 0, 3]

{-| A program that uses the "mergesort" function.
 -}
mergesortProg :: Prog
mergesortProg =
  prog [lenBody, takeBody, dropBody, mergeBody, mergesortBody] mergesortEx

{-| A function that creates an expression that uses "mergesort"
 - on a given list of numbers.
 -}
mergesortExList :: [Int] -> Expr
mergesortExList = app (ref "mergesort") . genIlist

{-| A function that creates a program that uses "mergesort"
 - on a given list of numbers.
 -}
mergesortProgList :: [Int] -> Prog
mergesortProgList =
  prog [lenBody, takeBody, dropBody, mergeBody, mergesortBody] . mergesortExList

mapFactEx :: Expr
mapFactEx = apps (ref "map") [ref "fact", genIlist [3, 4]]

mapFactProg :: Prog
mapFactProg = prog [mapBody, factBody] mapFactEx

{-| An expression using "insertSorted".
 -}
insertSortedEx :: Expr
insertSortedEx = apps (ref "insertSorted") [icon 3, genIlist [1, 2, 4, 5]]

{-| A program using "insertSorted".
 -}
insertSortedProg :: Prog
insertSortedProg = prog [insertSortedBody] insertSortedEx

{-| An expression insertion sorting a list.
 -}
insertionSortEx :: Expr
insertionSortEx = app (ref "insertionSort") $ genIlist [7, 24, 36, 72, 5]

{-| A program insertion sorting a list.
 -}
insertionSortProg :: Prog
insertionSortProg = prog [insertSortedBody, insertionSortBody] insertionSortEx

{-| An expression using "square"
-}
squareEx :: Expr
squareEx = app (ref "sqr") (app (ref "sqr") (binop Plus (icon 2) (icon 3)))

{-| A program using nested "square"
-}
squareProg :: Prog
squareProg = prog [squareBody] squareEx

{-| A program using "square"
-}
simplesquareProg :: Prog
simplesquareProg =
  prog [squareBody] $ app (ref "sqr") (binop Plus (icon 2) (icon 3))

{-| An expression to find minimum element in a list
-}
minEx :: Expr
minEx = app (ref "min") $ genIlist [7, 2]

{-| A program to find the minimum element in a list
-}
minProg :: Prog
minProg = prog [minBody, minEBody] minEx

{-| Binary tree examples
-}

tree :: Expr -> Expr -> Expr -> Expr
tree x l r = apps (dcon "N") [x, l, r]
  --app (app (app (dcon "Node") x) l) r

convertAST :: Tree Int -> Expr
convertAST (Leaf) = dcon "L"
convertAST (Node y l r) = tree (icon y) (convertAST l) $ convertAST r

t1 :: Expr
t1 =  convertAST $ createBST' [10, 20, 3, 4, 16, 27, 34]

t2 :: Expr
t2 =  convertAST $ createBST' []

t3 :: Expr
t3 =  convertAST $ createBST' [10, 20, 3, 4, 16, 15, 17, 27, 34]

{-| Program to search in a Binary Search tree
-}
searchBinaryBody :: Decl
searchBinaryBody
    = let_ "search"
        $
        abs_ "x" $ abs_ "t" $
         case_ (ref "t")
           [
                (CPat "L" [], bcon False),
                (CPat "N" [VPat "y", VPat "l", VPat "r"]
                  ,
                  cond (binop Gt (ref "y") $ ref "x")
                  (
                    apps (ref "search") [ref "x", ref "l"]
                  )
                  (
                    cond (binop Gt (ref "x") (ref "y"))
                    (
                      apps (ref "search") [ref "x", ref "r"]
                    )
                    (
                      bcon True
                    )
                  )
                )
           ]

searchBinaryProg :: Prog
searchBinaryProg = prog [searchBinaryBody] $ apps (ref "search") [icon 3, t1]

{-| Program to insert a node in a Binary Search tree
-}

insertBinaryBody :: Decl
insertBinaryBody
    = let_ "insert"
        $
        abs_ "x" $ abs_ "t" $
         case_ (ref "t")
           [
              (CPat "L" [], tree (ref "x") (dcon "L") (dcon "L")),
              (CPat "N" [VPat "y", VPat "l", VPat "r"]
              ,
               cond (binop Gt (ref "y") $ ref "x")
               (
                tree (ref "y") (apps (ref "insert") [ref "x", ref "l"]) $ ref "r"
               )
               (
                cond (binop Gt (ref "x") $ ref "y")
                (
                  tree (ref "y") (ref "l") $ apps (ref "insert") [ref "x", ref "r"]
                )
                (
                  ref "t"
                )
               )
              )
           ]

insertBinaryProg :: Prog
insertBinaryProg = prog [insertBinaryBody] $ apps (ref "insert") [icon 13, t1]


{-| Program to find inorder predecessor in a Binary Search tree
-}

inOrdPredBody :: Decl
inOrdPredBody
    = let_ "inordPred"
        $ abs_ "t" $
           case_ (ref "t")
             [
               (CPat "N" [VPat "y", VPat "l", CPat "L" []],
                  ref "y"
               ),
               (CPat "N" [VPat "y", VPat "l", VPat "r"],
                  app (ref "inordPred") $ ref "r"
               )
             ]

inOrdPredProg :: Prog
inOrdPredProg = prog [inOrdPredBody] $ flip app t3 $ ref "inordPred"

{-| Program to delete a node from a Binary Search tree
-}

deleteBinaryBody :: Decl
deleteBinaryBody
    = let_ "delete" $
        abs_ "x" $ abs_ "t" $
          case_ (ref "t")
           [
             (CPat "L" [], dcon "L"),
             (CPat "N" [VPat "y", CPat "L" [], CPat "L" []],
              cond (binop Gt (ref "y") $ ref "x")
              (
                ref "t"
              )
              (
                cond (binop Gt (ref "x") $ ref "y")
                (
                  ref "t"
                )
                (
                  dcon "L"
                )
              )),
             (CPat "N" [VPat "y", VPat "l", CPat "L" []],
              cond (binop Gt (ref "y") $ ref "x")
              (
                tree (ref "y") (apps (ref "delete") [ref "x", ref "l"]) $ dcon "L"
              )
              (
                cond (binop Gt (ref "x") $ ref "y")
                (
                  ref "t"
                )
                (
                  ref "l"
                )
              )),
             (CPat "N" [VPat "y", CPat "L" [], VPat "r"],
              cond (binop Gt (ref "y") $ ref "x")
              (
                ref "t"
              )
              (
                cond (binop Gt (ref "x") $ ref "y")
                (
                  tree (ref "y") (dcon "L") $ apps (ref "delete") [ref "x", ref "r"]
                )
                (
                  ref "r"
                )
              )),
             (CPat "N" [VPat "y", VPat "l", VPat "r"],
              cond (binop Gt (ref "y") $ ref "x")
              (
                tree (ref "y") (apps (ref "delete") [ref "x", ref "l"]) $ ref "r"
              )
              (
                cond (binop Gt (ref "x") $ ref "y")
                (
                  tree (ref "y") (ref "l") $ apps (ref "delete") [ref "x", ref "r"]
                )
                (
                  let_ "z" (app (ref "inordPred") $ ref "l") $
                    tree (ref "z") (apps (ref "delete") [ref "z", ref "l"]) $ ref "r"
                )
              )
             )
           ]

deleteBinaryProg :: Prog
deleteBinaryProg = prog [inOrdPredBody, deleteBinaryBody] $ apps (ref "delete") [icon 20, t3]

-- New examples:

{-
let m f = foldr (\x ys->f x:ys) []
	    dbl x = 2*x
	 in
	    m dbl [2,3,4,5]
-}

reduceDoubleBody :: Expr
reduceDoubleBody
     = let_ "m"
          (abs_ "f" (apps (ref "foldr")
           [abs_ "x"
                (abs_ "ys" $ cons (app (ref "f") (ref "x")) (ref "ys"))
            , dcon "Nil"]))
         $ let_ "dbl"
              (abs_ "x" $ binop Times (icon 2) (ref "x"))
                $ apps (ref "m") [ref "dbl", genIlist [2, 3, 4, 5]]

reduceDoubleProg :: Prog
reduceDoubleProg = prog [reduceRBody] reduceDoubleBody

reduceRBody :: Decl
reduceRBody
   = let_ "foldr"
        $ abs_ "comb" $ abs_ "z" $ abs_ "l"
          $ case_
             (ref "l")
              [ (CPat "Nil" [], ref "z")
              , ( CPat "Cons" [VPat "x", VPat "xs"]
              , apps (ref "comb") [ref "x",
                               apps (ref "foldr") [ref "comb", ref "z", ref "xs"]]
                )
              ]
