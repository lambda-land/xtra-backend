module Xtra.Language.Env where
import Data.Bifunctor

newtype TaggedEnv k v t = TaggedEnv { unTaggedEnv :: [(k, (v, t))] }

instance (Eq k, Eq v) => Eq (TaggedEnv k v t) where
    e1 == e2 = e1 `subset` e2 && e2 `subset` e1

instance Functor (TaggedEnv k v) where
    fmap = lift . map . second . second

instance Bifunctor (TaggedEnv k) where
    bimap f g = lift $ map $ second $ bimap f g

lift :: ([(k, (v, t))] -> [(k, (w, s))]) -> TaggedEnv k v t -> TaggedEnv k w s
lift f (TaggedEnv ts) = TaggedEnv (f ts)

lift' :: ([(k, (v, t))] -> a) -> TaggedEnv k v t -> a
lift' f = f . unTaggedEnv

empty :: TaggedEnv k v t
empty = TaggedEnv []

bind :: k -> v -> t -> TaggedEnv k v t -> TaggedEnv k v t
bind k v t = lift ((k, (v,t)):)

get :: Eq k => k -> TaggedEnv k v t -> Maybe (v, t)
get = lift' . lookup

bindings :: TaggedEnv k v t -> [(k, v)]
bindings = lift' $ map $ second fst

keys :: TaggedEnv k v t -> [k]
keys = lift' $ map fst

filter :: ((k, (v, t)) -> Bool) -> TaggedEnv k v t -> TaggedEnv k v t
filter = lift . Prelude.filter

mapKeys :: (k -> k) -> TaggedEnv k v t -> TaggedEnv k v t
mapKeys = lift . map . first

subset :: (Eq k, Eq v) => TaggedEnv k v t -> TaggedEnv k v t -> Bool
subset e1 e2 = all id
    [ v1 == v2
    | k <- keys e1
    , let v1 = fst <$> get k e1
    , let v2 = fst <$> get k e2
    ]

delete :: Eq k => k -> TaggedEnv k v t -> TaggedEnv k v t
delete k = lift $ Prelude.filter $ (/=k) . fst

alter :: Eq k => (Maybe (v, t) -> Maybe (v, t)) -> k -> TaggedEnv k v t -> TaggedEnv k v t
alter f k = lift alter'
    where
        alter' []
            | Just (v,t) <- f Nothing = [(k, (v, t))]
            | otherwise = []
        alter' ((k', (v, t)):rest)
            | k' /= k = (k', (v, t)) : alter' rest
            | otherwise = maybe rest ((: alter' rest) . (,) k) $ f $ Just (v, t)
