module Xtra.Language.Prog where
import Xtra.Language.Syntax

import Data.Void

data ExtProg a = Prog (ExtExpr a)
type Prog = ExtProg Void

type ExtDecl a = ExtExpr a -> ExtExpr a
type Decl = ExtDecl Void

instance Show a => Show (ExtProg a) where
    show (Prog e) = show e

prog :: [ExtExpr a -> ExtExpr a] -> ExtExpr a -> ExtProg a
prog ds e = Prog $ foldr ($) e ds
