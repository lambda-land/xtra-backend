mkdir -p gen
mkdir -p gen/$1
./run.sh $1 > gen/$1/markdown.md
pandoc -s -f markdown -t html gen/$1/markdown.md -o gen/$1/index.html --template template.html
