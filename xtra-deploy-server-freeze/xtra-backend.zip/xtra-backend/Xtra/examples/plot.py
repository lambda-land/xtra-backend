import pandas as pd
from matplotlib import rcParams
import matplotlib.pyplot as plt

rcParams.update({'figure.autolayout': True})
rcParams.update({'font.size': 26})
rcParams['figure.figsize'] = 20, 20

data = pd.read_csv("stats.csv")
data.columns = data.columns.str.strip()
data = data.sort_values(by="OriginalNodes", ascending=False)

x = data.Name
plt.xlabel('Name')
plt.xticks(rotation=90)

#y = data.OriginalNodes
#plt.plot(x, y, linestyle='-', marker='o', label="Original Nodes")

y = data.ViewVisible
plt.scatter(x, y, label="View Visible")
y1 = data.OriginalViewRatio

for i,j,l in zip(x,y,y1):
    label = "{:.2f}".format(l)
    plt.annotate(label,
                 (i,j),
                 textcoords="offset points",
                 xytext=(0,10),
                 ha='center')

plt.legend(loc = "upper right")
plt.savefig('stats.png')
