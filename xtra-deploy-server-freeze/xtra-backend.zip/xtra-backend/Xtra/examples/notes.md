* Collision doesn't scale up (no recursion)
* Constant-Fold will roughly double, since there's an explanation node for every expression node.
* Constants may grow quadratically, since `concat` isn't properly hidden. (TODO) 
* Cross Product will grow linearly.
* ?? re: binary search examples
* Evaluator with Abstractions will grow linearly (`nthElem` will only be called with effectively constant numbers ).
* Evaluator with Booleans will grow linearly
* Factorial will not grow.
* Filter will grow linearly.
* Merge List will grow linearly.
* Quicksort will grow linearly, but depth will increase logarithmically. Width will increase exponentially.
* Replicate will not grow.
* Reverse with accumulator will grow linearly.
* Reverse will grow linearly.
* Search binary search will grow logarithmically if the tree is balanced.
* Subsets will grow linearly.
* Sum will not grow.
* twice factorial will grow linearly unless a better recursion query is written. Then, it will not grow.
* Typecheck will grow linearly.

Linear: 11
Fixed: 4
Logarithmic: 1
Quadratic: 1

