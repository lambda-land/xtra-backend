The multiple occurences of `constantFold True` are due to the effects
of `factor`. Nodes are only shared after the initial evaluation, which means
that if two expressions become the same, they are no longer shared.

This is probably a good idea, because they may still have different
children (`accept` could've been used without `hide`).

Like some of the eval examples, the trouble here is that I can't use
_our implementation_ to hide specifically case expressions, which leads to
some weirdness. 
