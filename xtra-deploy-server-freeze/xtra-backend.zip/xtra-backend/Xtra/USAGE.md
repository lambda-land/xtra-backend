# USAGE
## Preliminary 

### The following is needed:

You need a copy of Stack installed on your system. Please see https://docs.haskellstack.org/en/stable/install_and_upgrade/

You will also need a dot client. On Linux, `xdot` is available on most distributions. 
On Mac, https://ports.macports.org/port/graphviz-gui/summary may work. Any other graphviz/dot viewer works,
as long as it can update the file as it is written to.

### installation
Clone the branch you want with `git clone https://github.com/lambda-land/Xtra/`. Navigate to the directory and run `stack install`. This will install Xtra to your stack binary location-- you may need to add it to your PATH on some operating systems. Alternatively, running `stack repl` will bring you into GHCI.

## xtra, the command
Once `xtra` is installed, you can run it from the command line on a given xtra program:
`xtra <filename>`. By default, `xtra` writes its traces to a file called `out.dot` in your current directory. If this is not to your liking, the flag `-o` changes the graph output file. `xtra fact.x -o Factorial.dot`will run the source code in `fact.x` and iteratively write traces to a file called `Factorial.dot`. `xtra` also supports scripting: to load a script, use the flag `-s`. Often times you will want to load the script called `prelude.qx`, so to carry on from our previous example:
```
xtra fact.x -o Factorial.dot -s prelude.qx
```
Will run the program written in `fact.x`, apply the script in `prelude.qx` to the trace, and then start writing the trace in `Factorial.dot`.
## xtra, the repl
When you run `xtra`, you are given a repl with which to interact with the current trace. These commands are supported:
```
print <filename> -- write the current graph to <filename>.
save <filename> -- save the current transformations to a script called <filename>.
load <filename> -- load the script in <filename> (equivalent to the -s flag)
stack -- print out the stack of transformations
undo -- undo last transformation
env -- inspect the environment of the current node.
```



