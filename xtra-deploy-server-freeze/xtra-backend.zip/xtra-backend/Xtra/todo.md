- ~Complete the semantics~
- ~Create smart constructors~
- ~Semantics of Prog~
- Collect properties about filter and cut (an algebgraic theory)
- ~Proper pretty printer for bindings~
- More prdicates (nonreflexive)
- ~Encode examples: Merge sort, insert into sorted list, insertion sor, etc~
- Convert Expr() to Expr Int -- Exploiting numbering of subexpressions
- Study evaluation traces and then dream up ideal explanation traces
- Identifying the abstractions/transformations from evaluation traces to explanation traces
- Work on expandTop function
- Find a way of distinguishing trees
- ~Label boxes with names of rule~s
- ~Separate cleanly the dot production and dot printing.~
- Figure out why equations are weird?
- In dot:
    * ~Print lists as [1,2,3]~
    * Pretty print equations
    * ~Remove ellipses~
    * Reducing size of box
    * Grey background and no boundary
- ~Removing type a~
- ~only tagtraces and no trees~

- ~Understood and hidden~
- Global filter stored in env
- Type trace filter
- Difference between syntax and semantics of predicate
- Lookups: separate trace + program, so you don't have to include lookups in trace.
- Explore effects

- ~Identifying node transformers~
- ~Lifting node trans to trace trans~
- ~Lifting trace trans to trace trans~
- App Cascades as single nodes
- ~Can we express box node expansions to top/bottom as generic filters in our query language?~
- ~Explore environments / how to display them~
------------------------------------------------------------------------
- ~Remove labels from intermediate boxes~
- ~Display option of hiding rules~
- partial applications
- ~dotted boxes~
- ~merge sort~
- ~length~
- ~insert into a sorted list~
------------------------------------------------------------------------
- ~Converting Traces to TagTraces~
- ~Data type for Visibility tags~
- ~Data type for Stickiness~
- Data type for structured tags
- ~Node Transformers~
- ~Trace transformers~
- ~Lifting node transformers to trace Transformers~
- ~Assigning node ids to TagTraces~
- ~Selecting node ids~
- ~Sequential composition of Trace Transformers~
- Saturating while trace generation
- ~When we add/replace a binding for a variable, we never take them out. It happens only locally. So only printing the recent bindings~

-----------------------------------------------------------------------------
 Future work
- How to change the visualization to factor out environments and create them as a secondary entry point
----------------------------------------------------------------------------------------------------
Define our language.
  - Concrete Syntax, Abstract Syntax
    - ~Numbers, Booleans as basic datatypes~
    - ~General datatype~
    - ~case expression~
    - ~application~
    - ~abstraction~
    - ~let and let-rec~
  - ~Define a pretty-printer for this language~
  - Define a parser (not important) IN-PROGRESS
  - Type Checker IN-PROGRESS
  - ~Define an execution semantics~
  - Collect examples/example programs (benchmarks) IN-PROGRESS
- ~What is a trace?~
  - ~Read "Functional Programs that Explain their Work"~
  - ~define trace datatype~
  - ~define trace semantics~
- ~Think about trace abstractions~
  - ~How can we compress parts of a trace?~
- ~Start thinking about the DSL for producing trace abstractions~
- ~Visual Interface for the DSL~
# Code Maintainablity
- Compile with (almost) no warnings under -Wall
- Document most functions
- Rename major data types to fit a consistent naming scheme
- Formatting
----------------------------------------------
- recursion
- standard queries
- Paper
- Trace semantics corresponds to value semantics
- Describing assume operations and hide operations
- Ternary relationship between explanation trace, operation stack
- Commutativity of operations
- Measure of explainability
- Comparison with other papers
