module Xtra.Runtime.EvalDAG where

import           Xtra.Language.Syntax
import           Xtra.Language.Hole
import           Control.Monad
import           Data.Maybe
import qualified Data.Map                      as M
import qualified Data.Set                      as S

data Visibility
    = Visible
    | Assumed
    | Hidden
    | HiddenTrans
    | Highlighted
    deriving (Eq, Show)

data Status
    = Permanent
    | Transient
    deriving (Eq, Show)

data Tag =
    Tag
        { vis :: Visibility
        , stat :: Status
        }
    deriving (Eq)

instance Show Tag where
  show (Tag v s) = "(" ++ show v ++ "," ++ show s ++ ")"

tag :: Tag
tag = Tag Visible Transient

-- | Eval Nodes
data Eval
    = Eval Env Expr NamedVal ELabel -- ^ Evaluation: Environment, Expression, Expression "shape", Result, Label
    | Match NamedVal Pat VBinding MLabel -- ^ Pattern match node
    | Prim Op Val Val Val PLabel -- ^ Primitive operation

-- | Pull expression out of an eval node
--   FIXME this seems inelegant
retrieveExpr :: Eval -> Maybe Expr
retrieveExpr (Eval _ e _ _) = Just e
retrieveExpr _                = Nothing

instance Show Eval where
  show (Eval _ e n _ ) = show e ++ "=>" ++ show n
  show (Match nv _ vb p) = show nv ++ "-> " ++ show vb
  show (Prim o v1 v2 v3 pl) =
    show v1 ++ show o ++ show v2 ++ "=" ++ show v3

instance Eq Eval where
  (Eval env1 de1 v1 l1) == (Eval env2 de2 v2 l2) =
    env1 == env2 && de1 == de2 && v1 == v2 && l1 == l2
  (Prim o1 v11 v21 v31 l1) == (Prim o2 v12 v22 v32 l2) =
    o1 == o2 && v11 == v12 && v21 == v22 && v31 == v32 && l1 == l2
  (Match v1 p1 b1 l1) == (Match v2 p2 b2 l2) =
    v1 == v2 && p1 == p2 && l1 == l2 && b1 == b2
  _ == _ = False

data HoleEval
  = HEval HoleyExpr NamedHoleyVal -- ELabel
  | HMatch NamedHoleyVal HoleyPat -- MLabel
  | HPrim Op HoleyVal HoleyVal HoleyVal -- PLabel
  | EvalHole Hole

matchHoleyEval :: HoleEval -> Eval -> Matcher Bool
matchHoleyEval (EvalHole _) _ = return True
matchHoleyEval (HEval e v) (Eval _ e' v' _) =
    liftM2 (&&) (matchHoleyExpr e e') (matchNamedHoleyVal v v')
matchHoleyEval (HMatch v p) (Match v' p' _ _) =
    liftM2 (&&) (matchNamedHoleyVal v v') (matchHoleyPat p p')
matchHoleyEval (HPrim o v1 v2 v3) (Prim o' v1' v2' v3' _)
    | o == o' = and <$> sequence (zipWith matchHoleyVal [v1,v2,v3] [v1', v2', v3'])
    | otherwise = return False
matchHoleyEval _ _ = return False

data ELabel
    = LVar
    | LBinOp
    | LAppF
    | LAppC
    | LAbs
    | LCase
    | LCondT
    | LCondF
    | LCon
    | LLet
    deriving (Eq, Show)

data MLabel
    = LPVar
    | LPCon
    deriving (Eq, Show)

data PLabel =
    LPrimOp
    deriving (Eq, Show)

data Node
    = SNode Tag Eval
    | RNode Tag Var NamedVal [ScopePair]
    deriving (Eq)

instance Show Node where
  show (SNode t e     ) = show e
  show (RNode t v nv s) = show v ++ ":" ++ show v


instance Ord Node where
  n `compare` n1 = GT

data EvalGr = EvalGr
    { nodes :: M.Map NodeId (Node, [NodeId])
    , scopes :: M.Map NodeId (S.Set Var)
    , rootNode :: NodeId
    }

reroot :: EvalGr -> NodeId -> EvalGr
reroot gr i = gr { rootNode = i }

adjust :: ((Node, [NodeId]) -> (Node, [NodeId])) -> NodeId -> EvalGr -> EvalGr
adjust f n gr = gr { nodes = M.adjust f n (nodes gr) }

unsafeFind :: EvalGr -> (NodeId -> (Node, [NodeId]))
unsafeFind g n = fromJust (M.lookup n (nodes g))

valEquiv :: Expr -> NamedVal -> Bool
valEquiv (Val x) y = x == y
valEquiv _       _ = False

