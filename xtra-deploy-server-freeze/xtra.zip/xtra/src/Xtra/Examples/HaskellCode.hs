module Xtra.Examples.HaskellCode where

data Tree a = Leaf | Node a (Tree a) (Tree a)
    deriving (Eq, Show)

{-createBST :: Ord a => [a] -> Tree a
createBST [] = Leaf
createBST (x:xs) = Node x l r
   where
     l = createBST $ filter (< x) xs
     r = createBST $ filter (> x) xs-}

createBST' :: Ord a => [a] -> Tree a
createBST' = foldl (flip insert) Leaf

search :: Ord a => a -> Tree a -> Bool
search x Leaf = False
search x (Node y l r)
   | x == y = True
   | x < y = search x l
   | x > y = search x r

insert :: Ord a => a -> Tree a -> Tree a
insert x Leaf = Node x Leaf Leaf
insert x t@(Node y l r)
   | x == y = t
   | x < y = Node y (insert x l) r
   | x > y = Node y l $ insert x r

delete :: Ord a => a -> Tree a -> Tree a
delete x Leaf = Leaf
delete x t@(Node y Leaf Leaf)
    | x == y = Leaf
    | otherwise = t
delete x t@(Node y l Leaf)
    | x == y = l
    | x < y = flip (Node y) Leaf $ delete x l
    | otherwise = t
delete x t@(Node y Leaf r)
    | x == y = r
    | x > y = Node y Leaf $ delete x r
    | otherwise = t
delete x t@(Node y l r)
    | x == y
       = let z = inordPred l
          in flip (Node z) r $ delete z l
    | x < y = flip (Node y) r $ delete x l
    | x > y = Node y l $ delete x r



inordPred :: Tree a -> a
inordPred (Node y l Leaf) = y
inordPred (Node y l r) = inordPred r


t :: Tree Int
t = createBST' [10, 7, 5, 4, 6, 8, 14, 12, 11, 13, 16, 15, 17]
