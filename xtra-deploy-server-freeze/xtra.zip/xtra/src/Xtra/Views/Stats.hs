module Xtra.Views.Stats where

import Xtra.Language.Syntax
import Xtra.Views.DagView
import Xtra.Transformations.Selectors
import Xtra.Runtime.EvalDAG
import qualified Data.Map as M
import Data.List
import Data.Semigroup

viewNodeCount :: DagView a -> Int
viewNodeCount = M.size . deref

viewVisibleCount :: DagView a -> Int
viewVisibleCount = M.size . M.filter (isVisible . fst) . deref
    where
        isVisible (Box _) = False
        isVisible n = True

nodeCount :: EvalGr -> Int
nodeCount = length . everywhere

visibleCount :: EvalGr -> Int
visibleCount gr = length
    $ filter (maybe False (isVisible . fst) . flip M.lookup (nodes gr))
    $ everywhere gr


depth :: EvalGr -> NodeId -> Int
depth gr@(EvalGr{nodes = g}) st
   = (+ 1) $ maximum $ safedepth ls
  where
       ls = lookupMap g st
       safedepth [] = [0]
       safedepth ls = map (depth gr) ls

zipSemi :: Semigroup m => [m] -> [m] -> [m]
zipSemi (x:xs) (y:ys) = (x <> y) : zipSemi xs ys
zipSemi xs [] = xs
zipSemi [] ys = ys
zipSemi [] [] = []

layers :: EvalGr -> NodeId -> [Int]
layers gr@EvalGr{nodes=g} st = 1 : (getSum <$> foldr (zipSemi . map Sum . layers gr) [] (lookupMap g st))

width' :: EvalGr -> NodeId -> Int
width' gr id = maximum $ layers gr id

width :: EvalGr -> NodeId -> Int
width gr@(EvalGr{nodes = g}) st
   = foldr (\n b -> max (width gr n) b) (length ls) ls
  where ls = lookupMap g st

viewDepth :: DagView a -> NodeId -> Int
viewDepth dv@(View{deref = dv'}) st
    = (+) 1 $ maximum $ safedepth $ map fst ls
    where
      ls = lookupMap dv' st
      safedepth [] = [0]
      safedepth ns = map (viewDepth dv) ns

viewLayers :: DagView a -> NodeId -> [Int]
viewLayers dv@View{deref=dv'} st = 1 : (getSum <$> foldr (zipSemi . map Sum . viewLayers dv) [] (map fst $ lookupMap dv' st))

viewWidth' :: DagView a -> NodeId -> Int
viewWidth' dv st = maximum $ viewLayers dv st

viewWidth :: DagView a -> NodeId -> Int
viewWidth dv@(View{deref = dv'}) st
    = foldr (\n b -> max (viewWidth dv n) b)
                              (length ls) $ map fst ls
      where ls = lookupMap dv' st


lookupMap :: (Ord a, Show a) => M.Map a (b, [c]) -> a -> [c]
lookupMap dv k
    = case M.lookup k dv of
        Nothing -> error $ "No value at id" ++ show k
        Just (_, ls) -> ls
