module Xtra.Views.DagView where
import           Xtra.Runtime.EvalDAG
import           Xtra.Language.Syntax
import           Xtra.Language.Prog
import           Xtra.Transformations.Selectors
import           Xtra.Runtime.Eval
import           Control.Applicative
import           Data.List                      ( nub )
import           Data.Maybe
import           Data.Bifunctor
import Xtra.Examples.Examples
import           Data.Function
import qualified Data.Graph.Inductive.Graph    as G
import qualified Data.Map                      as M
import qualified Data.Set as S
import qualified Data.GraphViz.Attributes as G3
import qualified Data.GraphViz.Attributes.Colors as G2
import qualified Data.GraphViz.Attributes.HTML as G1
import qualified Data.GraphViz.Types.Canonical as G4
import qualified Data.GraphViz.Attributes.Complete as G5
import qualified Data.Text.Lazy.IO as T
import qualified Data.Text.Lazy as T1
import Control.Monad.State
import Control.Monad.Reader
import Data.GraphViz


-- | Display graph type. This is what is shown to the user, and transformations
--  _should_ probably be applied on this only, not on previous representations. TODO discuss
--  D.F: I think we can make a storng case that the VNode can have _incomplete_ information.
--       A view is computed from a graph after every operation, so I don't think it makes
--       sense to keep information intact. For now, I'm removing the [NodeId] and NodeId
--       parameters from Box.
--  The user is displayed either:
data VNode a = VNode Node NodeId a -- ^ a normal node
             | Box a -- ^ a box (indicating hidden nodes)
             | VRef NodeId a  -- ^ a reference (indicated repeated computation)
          deriving (Show)

instance Functor VNode where
  fmap f (VNode n x a) = VNode n x (f a)
  fmap f (Box a) = Box (f a)
  fmap f (VRef n a) = VRef n (f a)

instance Labellable a => Labellable (VNode a) where
  toLabelValue (VNode n x a) = toLabelValue n

instance Labellable Node where
  toLabelValue (SNode t e) = toLabelValue . show $ e
  toLabelValue (RNode t x v s) = toLabelValue $ x ++ " = " ++ showValName [x] v
  toLabelValue _ = toLabelValue "working!"

instance Labellable () where
  toLabelValue () = toLabelValue "()"


-- | Generic Dag type
newtype Dag a b = View {deref :: M.Map NodeId (a, [(NodeId, b)])}
-- | Our representation doesn't make use of edge labels
type DagView a = Dag (VNode a) ()

deleteViewNode :: NodeId -> DagView () -> DagView ()
deleteViewNode n dv =
    View $ M.map (second (filter ((/=n) . fst))) $ M.delete n $ deref dv

-- | Helper function to retrieve in-edges out of our previous representation.
--   TODO add a Gr class to EvalGr. This would make this conversion easier.
--   might also allow some computations to be made cleaner?
leadsTo :: M.Map NodeId (a, [(NodeId, b)]) -> NodeId -> [(NodeId, b)]
leadsTo g n = map f $ filter (elem' n . snd . snd) (M.toList g)
  where elem' x xs = elem x (map fst xs)
        f (x, (y, ((a, b) : zs))) = (x, b)

noEdges x = (x, [])
noLabels x = (x, ())
xyyx (x,y) = (y,x)


-- | Graph instance for our Dag type
instance G.Graph Dag where
  empty = View (M.empty)
  isEmpty g = M.null (deref g)
  match i g = case M.lookup i (deref g) of
    Just (n, outE) ->
      let inE = leadsTo (deref g) i in
        ( Just (map xyyx inE, i, n, map xyyx outE)
        , View
            --  $ M.map (second $ filter $ (/=i) . fst)
            $ M.delete i (deref g)
        )
    Nothing -> (Nothing, g)
  mkGraph ls es =
    let begin = M.map (noEdges) (M.fromList (ls)) in View $ foldr addEdge begin es
    where addEdge (e1, e2, l) g  = M.adjust (second $ ((e2, l):)) e1 g
  labNodes g = map (second fst) (M.toList (deref g))

instance G.DynGraph Dag where
  (&) (in_, i, n, out_) g = let
    g' = foldr (\(l, ix) m -> M.adjust (second $ ((i, l):)) ix m) (deref g) in_
    in
    View $ M.insert i (n, map xyyx out_) g'

{- | Creates DagView
-}
createV :: EvalGr -> DagView ()
createV gr = fixShared
    $ mergeBoxes (rootNode gr) $ View 
    $ M.map (second (map noLabels))
    $ M.mapWithKey (first . convertN)
    $ M.filterWithKey (const . (`elem` reachableNodes))
    $ nodes gr
    where
        reachableNodes = everywhere gr
        fixShared dg = replaceShared [(rootNode gr + 1) ..] (findShared (rootNode gr) dg) dg

data BoxerState = BoxerState
    { remappedNodes :: M.Map NodeId NodeId
    , childNodes :: M.Map NodeId [NodeId]
    }

emptyState :: BoxerState
emptyState = BoxerState M.empty M.empty

type Boxer = ReaderT (Maybe NodeId) (State BoxerState)

inGroup :: NodeId -> Boxer a -> Boxer a
inGroup n b = do
    mn <- ask
    local (<|> Just n) b

outsideGroup :: Boxer a -> Boxer a
outsideGroup = local (const Nothing)

tryRemap :: NodeId -> Boxer ()
tryRemap n = do
    mn <- ask
    case mn of
        Just n' -> if n == n'
            then return ()
            else modify $ \s ->
                s { remappedNodes = M.alter (<|> Just n') n (remappedNodes s) }
        Nothing -> return ()

tryAddChild :: NodeId -> Boxer ()
tryAddChild n = do
    mn <- ask
    case mn of
        Just n' -> modify $ \s ->
            s { childNodes = M.alter (((++[n])<$>) . (<|> Just [])) n' (childNodes s) }
        Nothing -> return ()

mergeBoxes :: NodeId -> DagView () -> DagView ()
mergeBoxes s dv =
    flip (foldr deleteViewNode) remappedBoxes
    $ View $ M.mapWithKey changeNode $ deref
    $ foldr deleteViewNode dv childlessBoxes
    where
        changeNode :: NodeId -> (VNode (), [(NodeId, ())]) -> (VNode (), [(NodeId, ())])
        changeNode n b@(Box a, ns) = (Box a, nub $ fromMaybe [] $ (map (flip (,) ()) <$> M.lookup n cns))
        changeNode n b = second (map (first updateEdge)) b
        updateEdge n = fromMaybe n $ M.lookup n rns
        remappedBoxes = filter (`M.member` rns) allBoxes
        childlessBoxes = filter (fromMaybe True . (null <$>) . flip M.lookup cns) allBoxes
        allBoxes = filter isBox $ M.keys (deref dv)
        isBox n
            | Just (Box a, _) <- M.lookup n (deref dv) = True
            | otherwise = False
        BoxerState { remappedNodes = rns, childNodes = cns } = findBoxGroups s dv

findBoxGroups :: NodeId -> DagView () -> BoxerState
findBoxGroups s dv = snd $ runState (runReaderT (rec s) Nothing) emptyState
    where
        rec :: NodeId -> Boxer ()
        rec i = case M.lookup i (deref dv) of
            Just (Box _, is) -> inGroup i $ tryRemap i >> mapM_ (rec . fst) is 
            Just (_, is) -> tryAddChild i >> (outsideGroup $ mapM_ (rec . fst) is)
            Nothing -> return ()

type Desharer = State (M.Map NodeId [NodeId])

tally :: NodeId -> NodeId -> Desharer ()
tally f t = modify (M.alter (((++[f])<$>) . (<|> Just [])) t)

replaceShared :: [NodeId] -> [(NodeId, NodeId)] -> DagView () -> DagView ()
replaceShared ns es dg = View $ foldr ($) (deref dg) $ zipWith changeEdge es ns
    where
        changeEdge (f,t) i m = M.adjust (replace t i) f $ M.insert i (VRef t (), []) m
        replace t i = second $ map (first $ \t' -> if t' == t then i else t')

findShared :: NodeId -> DagView () -> [(NodeId, NodeId)]
findShared r gr = concatMap (drop 1 . nub . (uncurry $ map . flip (,)))
    $ M.toList $ snd
    $ runState (rec r) M.empty
    where
        rec :: NodeId -> Desharer ()
        rec i = case M.lookup i (deref gr) of
            Just (n, is) -> mapM_ (\(i',_) -> tally i i' >> rec i') is
            Nothing -> return ()

convertN :: NodeId -> Node -> VNode ()
convertN i n = case isVisible n of
  True  -> VNode n i ()
  False -> Box ()

isVisible :: Node -> Bool
isVisible (SNode (Tag Visible _) _    ) = True
isVisible (RNode (Tag Visible _) _ _ _) = True
isVisible _                             = False

-- | quick graph display FIXME labels
showgraph :: EvalGr -> IO ()
showgraph = preview . createV

-- | Write the current graph to out.dot. TODO fix formatting
view :: (Show a, Labellable a) => DagView a -> IO ()
view x = T.writeFile "out.dot" $ printDotGraph $ graphToDot nonClusteredParams{globalAttributes = [G4.GraphAttrs [G3.ordering G3.OutEdges]]
                          , fmtNode = \(_, l) -> case l of
                              VNode n x a ->
                                [shape PlainText
                                , xLabel x
                                ] ++ toAttrs S.empty n
                              VRef n a ->
                                [ shape Ellipse
                                , toLabel (G1.Text [(G1.Str $ T1.pack $ show n)])
                                , style dotted
                                , fontColor Gray
                                ]
                              Box a ->
                                [ shape BoxShape
                                , toLabel $ "..."
                                ]
                          , fmtEdge = const []} x


data Setting = EmitLabels
             | EmitScopePairs
  deriving (Eq, Ord)
type Settings = S.Set Setting

toAttrs :: Settings -> Node -> [Attribute]
toAttrs sns (SNode _ e) = case e of
  (Eval env e nv el) -> [ totext (show e ++ " ⇒ " ++ show nv)
                         , G5.FontName (T1.pack "Courier")
                         ] ++ if EmitLabels `S.member` sns
                              then [totext $ show el]
                              else []
  (Match nv pn vb ml) -> [ totext $ show nv ++ "|" ++ show pn ++ "↝" ++ show vb
                         , G5.FontName (T1.pack "Courier")
                         ] ++ if EmitLabels `S.member` sns
                              then [totext $ show ml]
                              else []
  (Prim o v1 v2 result pl) -> [totext $ show v1 ++ show o ++ show v2 ++ "=" ++ show result]
toAttrs sns (RNode _ v nv sp) = [totext $ v ++ " is " ++ show nv, G5.FontName (T1.pack "Courier")]






totext :: String -> Attribute
totext s = toLabel $ G1.Text [(G1.Str $ T1.pack $ s)]

