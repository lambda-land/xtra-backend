-- |

module Xtra.Language.Parser where

import Data.Void

import Data.Char
import Data.Functor
import Text.Parsec
import Text.Parsec.Expr
import qualified Text.Parsec.Token as P
import Text.Parsec.Language (haskellDef)
import Control.Monad

import Xtra.Language.Prog
import Xtra.Language.Syntax
import Xtra.Language.Hole

lexer = P.makeTokenParser haskellDef
    { P.reservedNames =
        ["let", "in", "if", "then", "else"
        , "case", "of", "True", "False"
        ]
    , P.reservedOpNames =
        [ "=", "*", "<", "<=", "=="
        , ">", ">=", "-", "/=", "!"
        , "*", "%", "/", "+", ":"
        , "{", "}", "\\", "->"
        ]
    }

number = fromInteger <$> P.natural lexer
lexeme = P.lexeme lexer
reserved = P.reserved lexer
parens = P.parens lexer
ident = P.identifier lexer
dIdent = lexeme $ (:) <$> upper <*> many alphaNum
whiteSpace = P.whiteSpace lexer
reservedOp = P.reservedOp lexer
brackets = P.brackets lexer
commaSep = P.commaSep lexer

upperIdent = try $ do { x <- ident; guard (isUpper . head $ x); return x}
lowerIdent = try $ do { x <- ident; guard (isLower . head $ x); return x}

type Parser = Parsec String ()

constV :: Parser Const
constV = I <$> number <|>
             D <$> dIdent <|>
             reserved "True" $> B True <|>
             reserved "False" $> B False

parseExtVal :: Show a => Parser a -> Parser (ExtVal a)
parseExtVal p =
  VApp <$> constV <*> many (parseNamedExtVal p) <|>
  VAbs <$ reservedOp "\\" <*> ident <* reservedOp "->" <*> parseExtExpr p <|>
  ValExt <$> p

parseNamedExtVal :: Show a => Parser a -> Parser (NamedExtVal a)
parseNamedExtVal p = NamedVal <$> parseExtVal p <*> option [] (reservedOp "!" *> (pure <$> ident))

genList' :: [ExtExpr a] -> ExtExpr a
genList' = foldr (app . app (dcon "Cons")) (dcon "Nil")

parseExtList :: Show a => Parser a -> Parser (ExtExpr a)
parseExtList p = brackets $ genList' <$> commaSep (parseExtExpr p)

parseExprBase :: Show a => Parser a -> Parser (ExtExpr a)
parseExprBase p =
  try (parens expr) <|>
  try (parseExtList p) <|>
  try (ExprExt <$> p) <|>
  try (reserved "let" *> (Let <$> ident <*> (reservedOp "=" *> expr) <*> (reserved "in" *> expr))) <|>
  try (reserved "case" *> (Case <$> expr <*> (reserved "of" *> many (parseExtBranch p)))) <|>
  try (Cond <$> (reserved "if" *> expr) <*> (reserved "then" *> expr) <*> (reserved "else" *> expr)) <|>
  try (Ref <$> ident) <|>
  try (Val <$> parseNamedExtVal p)
  where expr = parseExtExpr p

parseExprApps :: Show a => Parser a -> Parser (ExtExpr a)
parseExprApps p = foldl1 App <$> many1 (parseExprBase p)

parseExtExpr :: Show a => Parser a -> Parser (ExtExpr a)
parseExtExpr = buildExpressionParser ops . parseExprApps
  where
    ops = [[binOp ">" (BinOp Gt) AssocLeft],
           [binOp "*" (BinOp Times) AssocLeft, binOp "/" (BinOp Div) AssocLeft, binOp "%" (BinOp Mod) AssocLeft],
           [binOp "+" (BinOp Plus) AssocLeft, binOp "-" (BinOp Minus) AssocLeft],
           [binOp ":" (app . app (dcon "Cons")) AssocRight ]
           ]

parseVoid :: Parser Void
parseVoid = fail "No other constructor available!"

parseHole :: Parser Hole
parseHole = char '_' *> ((Hole <$> many1 alphaNum) <|> pure Anything) <* whiteSpace

binOp n f = Infix (try $ reservedOp n $> f)

parseExtBranch :: Show a => Parser a -> Parser (ExtBranch a)
parseExtBranch p = (,) <$> parseExtPat p <*> (reservedOp "->" *> parseExtExpr p <* lexeme (string ";"))

patList :: [ExtPat a] -> ExtPat a
patList = foldr (\x y -> CPat "Cons" [x,y]) (CPat "Nil" [])

parseExtPatList :: Show a => Parser a -> Parser (ExtPat a)
parseExtPatList p = brackets $ patList <$> commaSep (parseExtPat p)

parseExtPatParen :: Show a => Parser a -> Parser (ExtPat a)
parseExtPatParen p = parens $ do
    p1 <- parseExtPat p
    op <- "Pair" <$ reservedOp "," <|> "Cons" <$ reservedOp ":"
    p2 <- parseExtPat p
    return $ CPat op [p1,p2]

parseExtPat :: Show a => Parser a -> Parser (ExtPat a)
parseExtPat p = VPat <$> lowerIdent <|>
           IPat <$> number <|>
           reserved "True" $> BPat True <|>
           reserved "False" $> BPat False <|>
           parseExtPatList p <|>
           parseExtPatParen p <|>
           CPat <$> upperIdent <*> many (parseExtPat p) <|>
           PatExt <$> p

parseExtProg :: Show a => Parser a -> String -> Either String (ExtProg a)
parseExtProg p s =
  case runParser (parseExtExpr p <* eof) () "" s of
    Left err -> Left $ show err
    Right e -> Right $ Prog e

parseProg :: String -> Either String (ExtProg Void)
parseProg = parseExtProg parseVoid

parseHoleyProg :: String -> Either String (ExtProg Hole)
parseHoleyProg = parseExtProg parseHole

parseFileExt :: Show a => Parser a -> String -> IO (ExtProg a)
parseFileExt p f = do
  s <- readFile f
  case parseExtProg p s of
    Left str -> error $ "FAILED TO PARSE--\n" ++ str
    Right e -> pure e

factStr :: String
factStr = "let fact = \\x -> case x of 0 -> 1; y -> y * fact (x - 1); in fact 5"

holeyFactStr :: String
holeyFactStr = "let fact = \\x -> case x of 0 -> 1; y -> _ * _ (x - 1); in fact 5"
