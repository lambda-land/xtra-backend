module Xtra.Language.Hole where
import Xtra.Language.Syntax
import Xtra.Language.Prog
import qualified Data.Map as M
import Data.Void ( absurd )
import Data.Bifunctor
import Debug.Trace
import Control.Monad.State
import Control.Monad
import Control.Applicative

data Hole = Hole String |
            Anything deriving Eq

instance Show Hole where
    show (Hole x) = "_" ++ x
    show (Anything) = "___"

type HoleyPat = ExtPat Hole
type NamedHoleyVal = NamedExtVal Hole
type HoleyBranch = ExtBranch Hole
type HoleyVBinding = ExtVBinding Hole
type HoleyVal = ExtVal Hole
type HoleyExpr = ExtExpr Hole
type HoleyProg = ExtProg Hole

-- TODO zip doesn't work here.

data HoleRef = E Expr
             | NV NamedVal
             | P Pat
             deriving Show

type Matcher = State (M.Map String HoleRef)

matchListsWith :: (Show a, Show b) => (a -> b -> Matcher Bool) -> [a] -> [b] -> Matcher Bool
matchListsWith _ [] [] = pure True
matchListsWith f (a:as) (b:bs) = (&&) <$> f a b <*> matchListsWith f as bs
matchListsWith _ y z = (traceM $ "FAILURE!" ++ show y ++ show z) >> pure False

matchHoleyPat :: HoleyPat -> Pat -> Matcher Bool
matchHoleyPat (PatExt (Hole x)) p = do
  v <- gets (M.lookup x)
  case v of
    Just (P p') -> traceM ("pat match") >> pure $ p == p'
    Nothing -> modify (M.insert x (P p)) *> pure True
    _ -> pure False
matchHoleyPat (PatExt (Anything)) p = pure True

matchHoleyPat (VPat x1) (VPat x2) = pure $ x1 == x2
matchHoleyPat (CPat c1 ps1) (CPat c2 ps2) =
    (&&) <$> (pure $ c1 == c2) <*> matchListsWith matchHoleyPat ps1 ps2
matchHoleyPat (IPat i1) (IPat i2) = pure $ i1 == i2
matchHoleyPat (BPat b1) (BPat b2) = pure $ b1 == b2
matchHoleyPat _ _ = pure $ False

matchHoleyExpr :: HoleyExpr -> Expr -> Matcher Bool
matchHoleyExpr (ExprExt (Hole n)) e = do
  v <- gets (M.lookup n)
  case v of
    (Just (E e')) -> (traceM "attempting exp match") >> pure $ e == e'
    (Just (NV nv)) -> case e of
      (Val v') -> (traceM $ "im matching " ++ show nv ++ show v') >>  pure $ nv == v'
      _ -> pure False
    Nothing -> modify (M.insert n (E e)) *> pure True
    _ -> pure False
matchHoleyExpr (ExprExt (Anything)) e = pure True
matchHoleyExpr (Val hv) (Val v) = matchNamedHoleyVal hv v
matchHoleyExpr (Let x1 e1 e1') (Let x2 e2 e2') =
    and <$> sequence [pure $ x1 == x2
                     ,matchHoleyExpr e1 e2
                     ,matchHoleyExpr e1' e2']
matchHoleyExpr (BinOp o1 l1 r1) (BinOp o2 l2 r2) =
    and <$> sequence [pure $ o1 == o2
                     ,matchHoleyExpr l1 l2
                     ,matchHoleyExpr r1 r2]
matchHoleyExpr (App l1 r1) (App l2 r2) = (&&) <$> matchHoleyExpr l1 l2 <*> matchHoleyExpr r1 r2
matchHoleyExpr e@(App l1 r1) (Val (NamedVal (VApp (D s) as) []))
    | (Val (NamedVal (VApp (D s') []) []), as') <- collectApps e =
        (&& (length as == length as' && s == s')) <$> and <$> zipWithM matchHoleyExpr as' (Val <$> as)
    | otherwise = return False
matchHoleyExpr (Case e1 bs1) (Case e2 bs2) =
    (&&) <$> matchHoleyExpr e1 e2 <*> matchListsWith matchHoleyBranch bs1 bs2
matchHoleyExpr (Cond c1 t1 e1) (Cond c2 t2 e2) =
    and <$> sequence ((uncurry matchHoleyExpr) <$> [(c1,c2), (t1, t2), (e1, e2)])
matchHoleyExpr x y
    | Just True <- liftA2 (==) (getEffectiveName x) (getEffectiveName y) = return True
    | otherwise = (traceM $"match Failed!" ++ show x ++ show y) >> pure $ False

collectApps :: ExtExpr a -> (ExtExpr a, [ExtExpr a])
collectApps = second reverse . rec
    where
        rec (App l r) = second (r:) $ rec l
        rec e = (e, [])

getEffectiveName :: ExtExpr a -> Maybe String
getEffectiveName (Ref x) = Just x
getEffectiveName (Val (NamedVal v (n:ns))) = Just n
getEffectiveName _ = Nothing

matchHoleyVal :: HoleyVal -> Val -> Matcher Bool
matchHoleyVal (ValExt (Hole n)) x = do
  v <- gets (M.lookup n)
  case v of
    Just (NV (NamedVal nv _)) -> pure $ nv == x
    Just (E e) -> matchHoleyExpr (absurd <$> e) (Val (NamedVal x []))
    Nothing -> modify (M.insert n (NV (NamedVal x []))) *> pure True
    _ -> pure False
matchHoleyVal (ValExt Anything) _ = pure True
matchHoleyVal (VApp c1 vs1) (VApp c2 vs2) = (&&) <$> (pure $ c1 == c2) <*> matchListsWith matchNamedHoleyVal vs1 vs2
matchHoleyVal (VAbs x1 e1) (VAbs x2 e2) = (&&) <$> (pure $ x1 == x2) <*> (matchHoleyExpr e1 e2)
matchHoleyVal _ _ = pure False

matchNamedHoleyVal :: NamedHoleyVal -> NamedVal -> Matcher Bool
matchNamedHoleyVal (NamedVal v1 ns1) (NamedVal v2 ns2) = -- (&&) <$> (matchHoleyVal v1 v2) <*> (pure $ ns1 == ns2)
    matchHoleyVal v1 v2

matchHoleyBranch :: HoleyBranch -> Branch -> Matcher Bool
matchHoleyBranch (hp, he) (p, e) = (&&) <$> matchHoleyPat hp p <*> matchHoleyExpr he e

runMatch :: Matcher a -> a
runMatch x = evalState x (M.empty)

exaaa = matchHoleyExpr ((App (Ref "fact") (Val (NamedVal (VApp (I 6) []) [])))) (App (Ref "fact") (Val (NamedVal (VApp (I 6) []) [])))
