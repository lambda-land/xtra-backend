{-# LANGUAGE DeriveFunctor #-}
module Xtra.Language.Syntax where

import Xtra.Language.Env ( TaggedEnv )

import Data.List ( intercalate )
import Data.Void ( Void )
import Data.Bifunctor ( Bifunctor(bimap) )
import qualified Data.Set as S

type Var = String

class Vars a where
    vars :: a -> S.Set Var

type Cons = String

type NodeId = Int

type ExtBranch a = (ExtPat a, ExtExpr a)
type Branch = (Pat, Expr)

data Op
    = Plus
    | Times
    | Minus
    | Div
    | Gt
    | Mod
    deriving (Eq)

instance Show Op where
    show Plus = "+"
    show Times = "*"
    show Minus = "-"
    show Div = "/"
    show Gt = ">"
    show Mod = "%"

{-| Gets precedence of the given operator.
 -}
prec :: Op -> Int
prec Gt = 0
prec Plus = 0
prec Minus = 0
prec Times = 1
prec Div = 1
prec Mod = 1

associatesWith :: Op -> Op -> Bool
associatesWith Gt _ = False
associatesWith Div _ = False
associatesWith Mod _ = False
associatesWith o o' = o == o'

data ExtPat a
    = VPat Var
    | CPat Cons [ExtPat a]
    | IPat Int
    | BPat Bool
    | PatExt a
    deriving (Eq, Functor)
type Pat = ExtPat Void

instance Vars (ExtPat a) where
    vars (VPat v) = S.singleton v
    vars (CPat c ps) = foldr (S.union . vars) S.empty ps
    vars _ = S.empty

instance Show a => Show (ExtPat a) where
    show (VPat v) = v
    show (CPat c cs)
        | c == "Nil" = foldl (\x y -> x ++ " " ++ y) "[]" $ map show cs
        | c == "Cons" = printPat $ accumP cs
        | c == "(,)" = case cs of
                         (a:b:_) -> "(" ++ show a ++ "," ++ show b ++ ")"
        | otherwise = foldl (\x y -> x ++ " " ++ y) c $ map show cs
    show (IPat i) = show i
    show (BPat b) = show b
    show (PatExt a) = show a

printPat :: Show a => [ExtPat a] -> String
printPat (p1:p2:[]) = "(" ++ show p1 ++ ":" ++ show p2 ++ ")"
printPat ps = "[" ++ (listToStr ", " ps show) ++ "]"

accumP :: [ExtPat a] -> [ExtPat a]
accumP [] = []
accumP ((CPat "Cons" cs):ps) = accumP cs ++ accumP ps
accumP (p:ps) = p : accumP ps

data ExtExpr a
    = Val (NamedExtVal a)
    | Let Var (ExtExpr a) (ExtExpr a)
    | Ref Var
    | BinOp Op (ExtExpr a) (ExtExpr a)
    | App (ExtExpr a) (ExtExpr a)
    | Case (ExtExpr a) [ExtBranch a]
    | Cond (ExtExpr a) (ExtExpr a) (ExtExpr a)
    | ExprExt a
    deriving (Eq, Functor)
type Expr = ExtExpr Void

type IsLeft = Bool

instance Vars (ExtExpr a) where
    vars (Let x e e') = S.delete x $ S.union (vars e) (vars e')
    vars (Ref x) = S.singleton x
    vars (BinOp o l r) = S.union (vars l) (vars r)
    vars (App l r) =  S.union (vars l) (vars r)
    vars (Case e bs) = S.union (vars e)
        $ foldr S.union S.empty 
        $ map (uncurry (flip S.difference) . bimap vars vars) bs
    vars (Cond i t e) = S.union (vars i) $ S.union (vars t) (vars e)
    vars (Val (NamedVal v ns)) = vars v -- TODO: `repr` function?
    vars _ = S.empty

instance Show a => Show (ExtExpr a) where
    show (Ref t) = t
    show (Let v e e') = "let " ++ v ++ " = " ++ show e ++ " in " ++ show e'
    show e@(BinOp o l r) = ls ++ show o ++ rs
      where
        (ls, rs) = (parenthIfNeeded e l True, parenthIfNeeded e r False)
    show e@App {} = printApp e
    show (Case e bs) =
        "case " ++
        show e ++
        " of {" ++
        listToStr "; " bs (\(p, e') -> show p ++ " → " ++ show e') ++
        "}"
    show (Cond i t e) =
        "if " ++ show i ++ " then " ++ show t ++ " else " ++ show e
    show (Val v) = show v
    show (ExprExt a) = show a


{-| Check if an expression nested in another
 -  expression needs to be surrounded by
 -  parentheses.
 -}
requiresParenth :: ExtExpr a -> ExtExpr a -> IsLeft -> Bool
requiresParenth (BinOp o _ _) (BinOp o' _ _) isLeft
    | isLeft = prec o' < prec o
    | otherwise = not $ o `associatesWith` o'
requiresParenth App {} BinOp {} _ = True
requiresParenth App {} App {} _ = True
requiresParenth _ _ _ = False

{-| Parenthesize an expression if needed,
 -  given its parent expression.
 -}
parenthIfNeeded :: Show a => ExtExpr a -> ExtExpr a -> IsLeft -> String
parenthIfNeeded e e' d
    | requiresParenth e e' d = "(" ++ show e' ++ ")"
    | otherwise = show e'

printApp :: Show a => ExtExpr a -> String
printApp e =
    case collectList e of
        (App l r, []) -> show l ++ " " ++ parenthIfNeeded e r False
        (Val (NamedVal (VApp (D "(,)") []) _), [a, b])
                     -> "(" ++ show a ++ "," ++ show b ++ ")"
        l -> printList l

collectList :: ExtExpr a -> (ExtExpr a, [ExtExpr a])
collectList (App (App e@(Val (NamedVal (VApp (D "(,)") []) _)) a) b) = (e, [a, b])
collectList (App (App (Val (NamedVal (VApp (D "Cons") []) _)) x) xs) =
    let (t, l) = collectList xs
     in (t, x : l)
collectList e = (e, [])

printList :: Show a => (ExtExpr a, [ExtExpr a]) -> String
printList (Val (NamedVal (VApp (D "Nil") []) []), xs) =
    "[" ++ intercalate ", " (map show xs) ++ "]"
printList (e, xs) = intercalate ":" $ map show $ xs ++ [e]

type ExtVBinding a = [(Var, NamedExtVal a)]
type VBinding = ExtVBinding Void

type OriginId = NodeId
type ScopeId = NodeId
type ScopePair = (OriginId, ScopeId)

type GenExtEnv e t = TaggedEnv Var (NamedExtVal e) t
type GenEnv t = GenExtEnv Void t
type SimpleEnv = GenEnv ScopePair
type Env = GenEnv [ScopePair]

fromSimple :: SimpleEnv -> Env
fromSimple = fmap return

data Const
    = I Int
    | B Bool
    | D Cons
    deriving (Eq)

instance Show Const where
    show (I i) = show i
    show (B b) = show b
    show (D d) = d

data ExtVal a
    = VApp Const [NamedExtVal a]
    | VAbs Var (ExtExpr a)
    | ValExt a
    deriving (Eq, Functor)
type Val = ExtVal Void

instance Vars (ExtVal a) where
    vars (VApp c vs) = S.unions $ map (vars . getValue) vs
    vars (VAbs x e) = S.delete x $ vars e

instance Show a => Show (ExtVal a) where
    show (VApp (D "Nil") []) = "[]"
    show v@(VApp (D "Cons") [_, _]) = printVList $ collectVList v
    show (VApp (D "(,)") [a, b]) = "(" ++ show a ++ "," ++ show b ++ ")"
    show (VApp l []) = show l
    show (VApp l rs) =
        show l ++ " " ++ intercalate " " (map parenthIfNeededV rs)
    show (VAbs v e) = "λ" ++ v ++ "." ++ show e
    show (ValExt a) = show a

data NamedExtVal a = NamedVal (ExtVal a) [Var] deriving(Functor)
type NamedVal = NamedExtVal Void

instance Show a => Show (NamedExtVal a) where
    show = showValName []

instance Eq a => Eq (NamedExtVal a) where
    (NamedVal v1 _) == (NamedVal v2 _) = v1 == v2

mkNamedVal :: ExtVal a -> NamedExtVal a
mkNamedVal v = NamedVal v []

getValue :: NamedExtVal a -> ExtVal a
getValue (NamedVal v _) = v

getNames :: NamedExtVal a -> [Var]
getNames (NamedVal _ vs) = vs

addName :: Var -> NamedExtVal a -> NamedExtVal a
addName x (NamedVal v xs) = NamedVal v (xs ++ [x])

showValName :: Show a => [String] -> NamedExtVal a -> String
showValName avoid (NamedVal v@VAbs{} ns)
    | (n:_) <- Prelude.filter (not . (`elem` avoid)) ns = n
    | otherwise = show v
showValName _ (NamedVal v []) = show v
showValName _ (NamedVal v _) = show v

showValValue :: Show a => NamedExtVal a -> String
showValValue (NamedVal v _) = show v

collectVList :: ExtVal a -> (ExtVal a, [NamedExtVal a])
collectVList (VApp (D "Cons") [x, NamedVal xs _]) =
    let (t, l) = collectVList xs
     in (t, x : l)
collectVList v = (v, [])

printVList :: Show a => (ExtVal a, [NamedExtVal a]) -> String
printVList (VApp (D "Nil") [], vs) = "[" ++ intercalate ", " (map show vs) ++ "]"
printVList (v, vs) = (intercalate ":" $ map show vs) ++ show v

{-| Check if a value in an application needs to be surrounded by
 -  parentheses.
 -}
requiresParenthV :: NamedExtVal a -> Bool
requiresParenthV (NamedVal (VApp _ []) _) = False
requiresParenthV _ = True

{-| Parenthesize a value if needed,
 -  given its parent value.
 -}
parenthIfNeededV :: Show a => NamedExtVal a -> String
parenthIfNeededV v
    | requiresParenthV v = "(" ++ show v ++ ")"
    | otherwise = show v

{-| Prints an environment.
 -}
printVBinding :: Show a => ExtVBinding a -> String
printVBinding [] = ""
printVBinding [(x, v)] = sq $ x ++ ":" ++ show v
printVBinding ((x, v):env) =
    sq $ x ++ ":" ++ show v ++ ", " ++ printVBinding env

{-| Adds parentheses to the beginning and end of a string.
 -}
parenth :: String -> String
parenth d = "(" ++ d ++ ")"

listToStr :: String -> [a] -> (a -> String) -> String
listToStr _ [] _ = ""
listToStr a (c:cs) f = sq $ foldl (\x y -> x ++ a ++ y) (f c) $ map f cs

sq :: String -> String
sq s@[_] = s
sq ('"':s)
    | last s == '"' = init s
    | otherwise = s
sq ('\'':s)
    | last s == '\'' = init s
    | otherwise = s
sq s = s

-- Smart constructors
infixl 0 $$

icon :: Int -> ExtExpr a
icon i = Val (NamedVal (VApp (I i) []) [])

bcon :: Bool -> ExtExpr a
bcon b = Val (NamedVal (VApp (B b) []) [])

dcon :: Cons -> ExtExpr a
dcon d = Val (NamedVal (VApp (D d) []) [])

($$) :: ExtExpr a -> ExtExpr a -> ExtExpr a
($$) = app

cons :: ExtExpr a -> ExtExpr a -> ExtExpr a
cons = app . app (dcon "Cons")

ref :: Var -> ExtExpr a
ref = Ref

binop :: Op -> ExtExpr a -> ExtExpr a -> ExtExpr a
binop = BinOp

abs_ :: Var -> ExtExpr a -> ExtExpr a
abs_ v e = Val (NamedVal (VAbs v e) [])

app :: ExtExpr a -> ExtExpr a -> ExtExpr a
app = App

let_ :: Var -> ExtExpr a -> ExtExpr a -> ExtExpr a
let_ = Let

case_ :: ExtExpr a -> [ExtBranch a] -> ExtExpr a
case_ = Case

cond :: ExtExpr a -> ExtExpr a -> ExtExpr a -> ExtExpr a
cond = Cond

{-| Operators
-}
notOp :: ExtExpr a -> ExtExpr a
notOp e = cond e (bcon False) $ bcon True
