-- |

module Xtra.Interface.Monad where

import           Prelude                 hiding ( getLine )

import           Control.Monad.State.Lazy

import           Data.Bifunctor

import           System.Console.Haskeline

import           Xtra.Language.Syntax
import qualified Xtra.Language.Env as Env
import           Xtra.Language.Prog

import           Xtra.Runtime.EvalDAG
import           Xtra.Runtime.DagEvaluator
import           Xtra.Runtime.Eval

import           Xtra.Transformations.Selectors
import           Xtra.Transformations.Operations

import           Xtra.Views.DagView
import           Xtra.Views.Stats

import           Data.List
import qualified Data.Map                      as M

import           Data.Maybe
import           Xtra.Interface.QueryLang

-- FIXME refactor/ actual syntax for this?
type Gr = EvalGr
type QueryEnv = M.Map String QueryVar

type REPL a = StateT [RState] (InputT IO) a

data RState = Env
  { graph :: Gr
  , operation :: Maybe (Gr -> Gr, String) -- A function and the input that generated it
  , focus :: Maybe NodeId
  , qEnv :: QueryEnv
      }

lkup :: String -> REPL (Maybe QueryVar)
lkup s = do
  e <- gets (qEnv . head)
  pure $ M.lookup s e

put :: String -> QueryFunction -> REPL ()
put n s =
  modify' (\(e@Env { qEnv = q } : xs) -> e { qEnv = M.insert n (Left s) q } : xs)


-- Retrieve string command
comm :: RState -> String
comm (Env _ Nothing       _ _) = ""
comm (Env _ (Just (_, s)) _ _) = s

setFocus :: Maybe NodeId -> REPL ()
setFocus n = modify (\(x@(Env g o f q) : xs) -> (Env g o f q) : x : xs)

getFocus :: REPL (Maybe NodeId)
getFocus = (focus . head) <$> get

applyG' :: (Gr -> Gr) -> String -> RState -> RState
applyG' f s (Env g _ y q) = Env (f g) (Just (f, s)) y q

applyG :: (Gr -> Gr) -> String -> [RState] -> [RState]
applyG f s (e : es) = (applyG' f s e) : e : es
applyG _ _ []       = [] -- Bad!

println :: String -> REPL ()
println x = lift $ outputStrLn x

dispEnv :: REPL ()
dispEnv = do
  f <- getFocus
  case f of
    Nothing -> println "No node currently focused."
    Just fc -> do
      gr <- (unsafeFind . graph . head) <$> get
      let (node, _) = gr fc
      case node of
        (SNode _ (Eval e _ _ _)) -> mapM_ (println . show) (Env.bindings e)
        _ -> println "err: current target is not a eval node."

getTargetNode :: REPL (Maybe Node)
getTargetNode = do
  f <- getFocus
  case f of
    Nothing -> println "No node focused." >> pure Nothing
    Just fc -> do
      gr <- (unsafeFind . graph . head) <$> get
      let (node, _) = gr fc
      pure (Just node)

doOp :: Operation -> String -> REPL ()
doOp o l = do
  println "About to perform op."
  modify' $ applyG (perform o) l

writeScript :: String -> REPL ()
writeScript s = do
  st <- (map comm) <$> get
  liftIO $ writeFile s $ unlines . reverse $ st


printStack :: REPL ()
printStack = get >>= mapM_ (lift . outputStrLn . comm)

undo :: REPL ()
undo = modify tail

getLine :: REPL (Maybe String)
getLine = lift $ getInputLine "explain> "

writeTrace :: String -> REPL ()
writeTrace s = do
  e <- head <$> get -- FIXME
  let t = graph e
  liftIO $ view . createV $ t

writeStats :: REPL ()
writeStats = do
    g <- gets (graph . head)
    let r = getRootNode g
    g' <- gets (graph . last)
    let r' = getRootNode g'
    let v = createV g
    liftIO $ putStr "[stats]"
    liftIO $ putStrLn $ intercalate ", " $ map show
        $ --[ width g' r', viewWidth v r]
        [width' g r, depth g r, nodeCount g', visibleCount g', viewWidth' v r, viewDepth v r, viewNodeCount v, viewVisibleCount v ]

getRootNode :: EvalGr -> NodeId
getRootNode (EvalGr{rootNode = r}) = r
