module Xtra.Transformations.TagTrans where
import Xtra.Runtime.EvalDAG

type Trans = Tag -> Tag

trans :: Visibility -> Trans
trans _ t@(Tag _ Permanent) = t
trans v _ = (Tag v Transient)

lock :: Trans
lock (Tag v _) = (Tag v Permanent)

hide :: Trans
hide = trans Hidden

highlight :: Trans
highlight = trans Highlighted


hideP :: Trans
hideP = lock . hide

hideAll :: Trans
hideAll = trans HiddenTrans

hideAllP :: Trans
hideAllP = lock . hideAll

assumed :: Trans
assumed = trans Assumed

assumedP :: Trans
assumedP = lock . assumed

reveal :: Trans
reveal = trans Visible

revealP :: Trans
revealP = lock . reveal
