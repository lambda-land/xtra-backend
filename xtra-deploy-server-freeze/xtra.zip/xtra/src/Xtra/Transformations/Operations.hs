-- |

module Xtra.Transformations.Operations where

import           Xtra.Language.Syntax hiding (vars)
import qualified Xtra.Language.Env as Env
import qualified Xtra.Language.Syntax as St
--import Xtra.Runtime.DisplayExpr
import           Xtra.Transformations.Selectors
import           Xtra.Runtime.EvalDAG
import           Xtra.Transformations.TagTrans  hiding ( hide )
import qualified Xtra.Transformations.TagTrans  as TagTrans
import           Data.Bifunctor                 ( second
                                                , first
                                                )
import           Data.Bool
import           Data.List                      ( elem
                                                , nub
                                                , splitAt
                                                )
import           Data.Maybe
import           Debug.Trace
import           Data.Maybe
import           Control.Monad
import           Control.Monad.Reader
import           Control.Monad.State
import qualified Data.Map                      as M
import qualified Data.Set                      as S


data Operation = Accept Selector | Hide Selector | Factor Selector

data SubstState = SubstState { vars :: S.Set Var, expr :: Expr, val :: NamedVal }
type Substituter = Reader SubstState

withVar :: Var -> a -> Substituter a -> Substituter a
withVar v a s = do
    isBound <- reader (S.member v . vars)
    if isBound then return a else s

tryReplace :: Substituter Expr -> Substituter Expr
tryReplace s = do
    e <- s
    e' <- reader expr
    if e == e' then Val <$> reader val else return e

subst :: Expr -> NamedVal -> Expr -> Expr
subst e v e' = runReader (rec e') (SubstState (St.vars e) e v)
    where
        tryVar x e = withVar x e $ rec e
        recBranch (p, e) = (,) p <$> foldr (flip withVar e) (rec e) (St.vars p)
        rec = tryReplace . rec'
        rec' (Let x e e') = liftM2 (Let x) (tryVar x e) (tryVar x e')
        rec' (BinOp o l r) = liftM2 (BinOp o) (rec l) (rec r)
        rec' (App l r) = liftM2 App (rec l) (rec r)
        rec' (Case e bs) = liftM2 Case (rec e) (mapM recBranch bs)
        rec' (Cond i t e) = liftM3 Cond (rec i) (rec t) (rec e)
        rec' (Val nv) = Val <$> recNv nv
        rec' e = return e

        recNv (NamedVal v ns) = flip NamedVal ns <$> recV v

        recV (VApp c nvs) = VApp c <$> mapM recNv nvs
        recV (VAbs x e) = VAbs x <$> tryVar x e

data ScoperState = ScoperState { var :: String, seenOnce :: Bool }
type Scoper = ReaderT ScoperState (State (S.Set NodeId))

withVars :: S.Set Var -> Scoper () -> Scoper ()
withVars xs s = do
    varOccurs <- reader ((`S.member` xs) . var)
    if varOccurs
     then do
        seen <- reader seenOnce
        if seen
         then return ()
         else local (\s -> s { seenOnce = True }) s
     else s

recordNode :: NodeId -> Scoper ()
recordNode i = modify (S.insert i)

varScope :: NodeId -> Var -> EvalGr -> S.Set NodeId
varScope i x gr = snd $ runState (runReaderT (rec i) (ScoperState x False)) S.empty
    where
        rec i' = case (M.lookup i' (nodes gr), M.lookup i' (scopes gr)) of
            (Just (n, is), Just xs) -> withVars xs $ recordNode i' >> mapM_ rec is
            (Just (n, is), _) -> recordNode i' >> mapM_ rec is
            _ -> return ()

bindingScope :: EvalGr -> Var -> [(NodeId, NodeId)] -> S.Set NodeId
bindingScope gr x = foldr (\(_, i) -> S.union (varScope i x gr)) S.empty

evalScope :: NodeId -> EvalGr -> S.Set NodeId
evalScope i gr = case M.lookup i (nodes gr) of
    Just (SNode _ (Eval env e v _), is) -> foldr (S.intersection . singleScope) allNodes $ Env.keys env
        where
            allNodes = M.keysSet (nodes gr)
            vars = Env.keys env
            singleScope x = fromMaybe S.empty $ bindingScope gr x . snd <$> Env.get x env
    Just (RNode _ x v bs, is) -> bindingScope gr x bs

getSubstitution :: NodeId -> EvalGr -> Maybe (Expr, NamedVal)
getSubstitution i gr = case M.lookup i (nodes gr) of
    Just (SNode _ (Eval _ e v _), _) -> Just (e, v)
    Just (RNode _ x v _, _) -> Just (Ref x, v)
    _ -> Nothing

makeSubstitution :: Expr -> NamedVal -> NodeId -> EvalGr -> EvalGr
makeSubstitution e v i gr = gr { nodes = M.adjust mkSubst i (nodes gr) }
    where
        mkSubst (SNode t (Eval env e' v' l), is) = (SNode t (Eval env (subst e v e') v' l), is)
        mkSubst n = n

acceptNode :: NodeId -> EvalGr -> EvalGr
acceptNode i gr = case getSubstitution i gr of
    Just (e, v) -> foldr (makeSubstitution e v) gr $ evalScope i gr
    Nothing -> gr

-- | Pull an expr out of a node.
deEval :: Node -> Maybe Expr
deEval (SNode _ e     ) = retrieveExpr e
deEval (RNode t v nv s) = Just (Val nv)

accept :: [NodeId] -> EvalGr -> EvalGr
accept is g = foldr acceptNode g is

hide :: [NodeId] -> EvalGr -> EvalGr
hide is g = g { nodes = foldr hideNode (nodes g) is }
    where
        hideNode' (RNode t x v b) = RNode (TagTrans.hide t) x v b
        hideNode' (SNode t e) = SNode (TagTrans.hide t) e
        hideNode i m = M.adjust (first hideNode') i m

perform :: Operation -> EvalGr -> EvalGr
perform (Accept s) gr = accept (s gr) gr
perform (Hide s) gr = hide (s gr) gr
perform (Factor s) gr = let nodes = s gr in accept nodes $ hide nodes gr
