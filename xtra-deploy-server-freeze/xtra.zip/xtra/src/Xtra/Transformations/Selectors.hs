module Xtra.Transformations.Selectors where
import           Prelude                 hiding ( pred
                                                , until
                                                )
import           Xtra.Runtime.EvalDAG
import           Xtra.Language.Syntax
import           Data.List                      ( elem
                                                , delete
                                                , nub
                                                , sort
                                                )
import qualified Data.Map                      as M

type Selector = EvalGr -> [NodeId]

everywhere :: Selector
everywhere gr = rec (rootNode gr)
    where
        ns = nodes gr
        rec i = case M.lookup i ns of
            Just (_, is) -> i : concatMap rec is
            Nothing -> []

{-| root combinator
-}
root :: Selector
root = return . rootNode

{-| or combinator
-}
or_ :: Selector -> Selector -> Selector
or_ s1 s2 dg = s1 dg ++ s2 dg

{-| and combinator
-}
and_ :: Selector -> Selector -> Selector
and_ s1 s2 dg = mutuals l1 l2
 where
  l1 = s1 dg
  l2 = s2 dg
  mutuals [] _ = []
  mutuals (x : xs) ys | x `elem` ys = x : mutuals xs (delete x ys)
                      | otherwise   = mutuals xs ys

{-| try combinator
-}
try_ :: Selector -> Selector
try_ sel dg = case sel dg of
  [] -> [rootNode dg]
  ns -> ns

{-| except combinator
-}
except :: Selector -> Selector -> Selector
except s1 s2 dg = filter (\n -> not (n `elem` exceptions)) $ s1 dg
    where exceptions = s2 dg

{-| then combinator
-}
then_ :: Selector -> Selector -> Selector
then_ l r dg = nub $ (nub $ l dg) >>= (r . reroot dg)

{-| fix combinator
-}
fix_ :: Selector -> Selector
fix_ sel dg = if l1 == l2 then l1 else then_ sel (fix_ sel) dg
 where
  l1 = sel dg
  l2 = then_ sel sel dg

{-| Recursion selector
-}
first_ :: Selector -> Selector
first_ s = s `except` (s `then_` s)

last_ :: Selector -> Selector
last_ s = fix_ $ try_ $ s `except` root

recursion :: Selector -> Selector
recursion s = notFirst `except` afterLast
 where
  notFirst  = s `then_` (s `except` root) `then_` everywhere
  afterLast = (last_ s) `then_` everywhere
