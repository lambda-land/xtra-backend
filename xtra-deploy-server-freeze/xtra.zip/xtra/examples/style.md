# Xtra Script Style Guidelines
## Hide Top-Level Lambdas
This is one of the most commonplace rules. The lambdas are very bulky, and don't
provide much value. All of our examples should hide all the top-level lambdas.
Ideally, this would be a line like this:

```
hide <let _X = _Y in _Z => _W>
```

However, this doesn't work, since our internal representation
of selectors does not allow for holes to replace variables in `let/in`.
So, you have to manually write out every query:

```
hide <let fact = _Y in _Z => _W>
hide <let twice = _Y in _Z => _W>
...
```

## Hide Reflexive Nodes
I actually think there are reasons _not_ to hide some reflexive nodes.
For example, in case expressions, if the body of the branch taken is trivial
(for example, returning 0), then there will very little indication as to why
a case expression evaluated to a particular value (there would be no subtree
showing the trivial evaluation). It may be in our interest to keep reflexive
nodes in that case. So in general, you should end your scripts with

```
hide reflexive
```

But sometimes, you may need to make exceptions:

```
hide reflexive except ...
```

## Factor Bindings
Experimentally, we've found that factoring bindings makes the program look nicer.
There are some exceptions for this. For instance, when we create the trace for
`twiceFact`, we deliberately exclude the factoring of `f = fact`, so that it's
clear how `twice fact` becomes `\x -> fact (fact x)`. So, in general:

```
factor binding
```

Possibly with some exceptions:

```
factor binding except ...
```
