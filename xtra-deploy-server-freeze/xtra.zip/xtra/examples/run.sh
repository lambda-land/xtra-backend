SOURCE_FILE=$(cat $1/source.txt | head -n 1)
(echo "runRepl $ $SOURCE_FILE"; cat $1/script.txt) | stack ghci | grep "\[stats\]" | sed "s/^.*\[stats\]//" > gen/$1/stats.txt
FILE_CONTENT=$(echo "print $ $SOURCE_FILE" | stack ghci 2>/dev/null | grep '^.*>' | cut -d'>' -f2- | head -n1)
mv out.dot gen/$1/out.dot
dot -T png -ogen/$1/figure.png gen/$1/out.dot

echo "# Program \`$SOURCE_FILE\`"
echo "## Notes"
cat $1/notes.md 2>/dev/null
echo ""
echo "## Source Code"
echo '```'
echo $FILE_CONTENT | sed 's/ in / in\n/g'
echo '```'
echo "## Trace Script"
echo '```'
cat $1/script.txt
echo '```'
echo "## Generated Trace"
echo "![Generated Trace](figure.png){ width=100% }"
