import pandas as pd

data = pd.read_csv("script_stats.csv")
data.columns = data.columns.str.strip()
print("Median:")
print(data.median(numeric_only=True))
print()
print("Max:")
print(data.max(numeric_only=True))
print()
print("Min:")
print(data.min(numeric_only=True))

print()
print("Non-prelude fraction:")
code_fraction = data['Minified'] / data['WithPrelude']
print("Median:", code_fraction.median())
print("Max:", code_fraction.max())
print("Min:", code_fraction.min())
