Rebuilder needed to be adjusted to account for recursion compression.
