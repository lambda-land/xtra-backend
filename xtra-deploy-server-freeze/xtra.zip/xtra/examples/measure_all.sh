echo "Name, WithPrelude, WithoutPrelude, Minified" > script_stats.csv
PRELUDE=$(echo "putStrLn $ \"[stats] \" ++ show (M.size prelude)" | stack ghci | grep "\[stats\]" | sed "s/^.*\[stats\]//")
echo $PRELUDE
for EXAMPLE in $(ls -d */ | sed 's/\///g' | grep -v 'gen' | grep -v 'venv'); do
    EXAMPLE_STATS=$(ruby measure.rb $EXAMPLE/script.txt $PRELUDE)
    echo "$EXAMPLE, $EXAMPLE_STATS" >> script_stats.csv
done
