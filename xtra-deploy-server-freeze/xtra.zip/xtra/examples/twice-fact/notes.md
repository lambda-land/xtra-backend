This is the second example from the paper. As mentioned in the `factProg` example, we can't
hide let expressions (because we can't put a hole where the variable is). Other than that,
it works out of the box, given the same modifications made to `factProg`.
