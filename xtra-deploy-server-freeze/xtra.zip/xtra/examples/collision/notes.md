# Checking for collisions, broken example
This is a rectangle-bounding box collision program that doesn't work. Originally I thought it was due to a mistake in the algorithm, but running the script and examining the resulting trace revealed that the "greater than or equal to" function was defined incorrectly: specifically, the node stating that `geq 0 0 => False`.

