filename = ARGV[0]
prelude_length = (ARGV[1] || "0").to_i
lines = File.open(filename)
  .readlines
  .map(&:chomp)
  .select { |it| it != "" }

lambda_hides = 0
reflexive_hides = 0
actions = {
  /hide <let ([a-zA-Z]*) = _[A-Z] in _[A-Z] => _[A-Z]>/ =>
    lambda { |line| lambda_hides += 1 },
  /hide reflexive/ =>
    lambda { |line| reflexive_hides += 1 }
}

lines.each do |line|
  actions.each do |regex, action|
    if line =~ regex then
      action.call(line)
    end
  end
end

total_count = lines.length
total_count -= (lambda_hides - 1) if lambda_hides != 0
total_count -= reflexive_hides
puts [prelude_length + total_count, lines.length, total_count].join ", "
