echo "Name, OriginalWidth, OriginalHeight, OriginalNodes, OriginalVisible, ViewWidth, ViewHeight, ViewNodes, ViewVisible" > stats.csv
for EXAMPLE in $(ls -d */ | sed 's/\///g' | grep -v 'gen'); do
    echo "Generating $EXAMPLE"
    ./generate.sh $EXAMPLE
    EXAMPLE_STATS=$(cat gen/$EXAMPLE/stats.txt)
    echo "$EXAMPLE, $EXAMPLE_STATS" >> stats.csv
done
