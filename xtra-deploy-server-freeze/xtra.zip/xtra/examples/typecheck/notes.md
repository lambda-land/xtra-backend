This example also suffers from a limitation of our implementation.
I can't specify that I want to hide all case expressions, which leaves some rather
bulky expressions in.

This actually seems to be, in some ways, an advantage. Most of the inner case
expressions have "trivial" bodies (`TInt`, for example), which gets picked
up by the reflexivity query and swept away. Seeing the cases, then, is a big plus;
Ideally, though, we'd only see the relevant case.

Using `(,)` to construct triples sadly doesn't render nicely (in fact, it renders incorrectly).
So, I used a `Triple` constructor instead. This is the second instance in which I pattern
matched to avoid nested case expressions; I think it looks nice in our tool.
