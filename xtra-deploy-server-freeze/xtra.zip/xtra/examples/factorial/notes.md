This is the canonical example from the paper.

There are a few things that still need to be addressed:

* It's impossible to write a pattern that captures any lambda, nor any let/in, because
there's no way to replace variables in holes.
* The `uniqueChildren` call takes too long, so we strip it out in this version.
* Factor is currently not implemented, but can easily be done using hide-then-accept.
