# Notes
- Linear traces are a lot nicer.
- Checkboxes for common predicates in UI
- "Base" predicate
